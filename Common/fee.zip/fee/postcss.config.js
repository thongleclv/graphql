module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    
    //Why we need this plugin postcss-antd-fixes?
    //     support antd + TailwindCSS preflight.css
    // fix button style conflict, ref: ant-design/ant-design#38794
    // support anchor tags with colorPrimary under any antd components
    'postcss-antd-fixes': {
      prefixes: ['vp-antd', 'ant'],
    },
  },
};
