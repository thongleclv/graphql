import type { Config } from 'tailwindcss';
const plugin = require('tailwindcss/plugin');

const config: Config = {
  content: ['./src/pages/**/*.{js,ts,jsx,tsx,mdx}', './src/modules/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          60: '043F9B',
          50: '#0060F6',
          40: '#4E8FF4',
          30: '#94BAF5',
          20: '#C9DCF9',
          10: '#E2EAFE',
        },
        yellow: {
          50: '#F49300',
          40: '#FFCD26',
          30: '#F8DB75',
          20: '#FBEEC1',
          10: '#FDFAE8',
        },
        blue: {
          60: '#008AB6',
          55: '#00B1EA',
          50: '#00BFFC',
          40: '#4FCFF8',
          30: '#91DFF8',
          20: '#CAF0FC',
          10: '#E7F9FF',
        },
        red: {
          50: '#F04438',
          40: '#F36960',
          30: '#F9B4AF',
          20: '#FCDAD7',
          10: '#FEEDEC',
        },
        green: {
          50: '#0D894F',
          40: '#33B76B',
          30: '#7EDCA6',
          20: '#C4EAD4',
          10: '#F0FDF7',
        },
        dark: {
          80: '#1A1C21',
          70: '#333843',
          60: '#667085',
          50: '#858D9D',
          40: '#C2C6CE',
          30: '#EBECEF',
          20: '#F9F9FC',
          10: '#FFFFFF',
        },
      },
    },
  },

  plugins: [
    plugin(function ({ addComponents, theme }: any) {
      addComponents({
        /* TYPOGRAPHY */
        /* ------------------------------------- */
        /* Headings */
        '.h1-t38m': {
          fontSize: '38px',
          fontWeight: '600',
          lineHeight: '46px',
        },
        '.h2-t30s': {
          fontSize: '30px',
          fontWeight: '600',
          lineHeight: '40px',
        },
        '.h3-t20s': {
          fontSize: '20px',
          fontWeight: '600',
          lineHeight: '28px',
        },
        '.h3-t20r': {
          fontSize: '20px',
          fontWeight: '400',
          lineHeight: '28px',
        },
        '.h4-t16b': {
          fontSize: '16px',
          fontWeight: '700',
          lineHeight: '24px',
        },
        '.h4-t16s': {
          fontSize: '16px',
          fontWeight: '600',
          lineHeight: '24px',
        },
        '.h4-t16m': {
          fontSize: '16px',
          fontWeight: '500',
          lineHeight: '24px',
        },
        '.h4-t16r': {
          fontSize: '16px',
          fontWeight: '400',
          lineHeight: '24px',
        },

        /* Body Text */

        '.body-t14b': {
          fontSize: '14px',
          fontWeight: '700',
          lineHeight: '22px',
        },
        '.body-t14s': {
          fontSize: '14px',
          fontWeight: '600',
          lineHeight: '22px',
        },
        '.body-t14m': {
          fontSize: '14px',
          fontWeight: '500',
          lineHeight: '22px',
        },
        '.body-t14r': {
          fontSize: '14px',
          fontWeight: '400',
          lineHeight: '22px',
        },
        '.body-t14r-underline': {
          fontSize: '14px',
          fontWeight: '400',
          lineHeight: '22px',
          textDecoration: 'underline',
        },
        '.body-t14r-strikethrough': {
          fontSize: '14px',
          fontWeight: '400',
          lineHeight: '22px',
          textDecoration: 'line-through',
        },

        /* Subtitles */

        '.subtitle-t12s': {
          fontSize: '12px',
          fontWeight: '600',
          lineHeight: '20px',
        },
        '.subtitle-t12m': {
          fontSize: '12px',
          fontWeight: '500',
          lineHeight: '20px',
        },
        '.subtitle-t12r': {
          fontSize: '12px',
          fontWeight: '400',
          lineHeight: '20px',
        },
      });
    }),
  ],
  important: true,
};
export default config;
