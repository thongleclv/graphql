import { Avatar, List } from '@/src/modules/common/components/ui';
import { Comment } from '../models';

export const CommentItem = ({ comment }: { comment: Comment }) => {
  return (
    <List.Item>
      <List.Item.Meta
        avatar={<Avatar src={comment?.createdBy?.avatar} />}
        title={comment?.createdBy.firstName + ' ' + comment?.createdBy.lastName}
        description={comment.content}
      />
    </List.Item>
  );
};
