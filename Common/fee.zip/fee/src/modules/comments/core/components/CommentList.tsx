import { List, Spin } from '@/src/modules/common/components/ui';
import { CommentAdd } from '.';
import { useComments } from '../hooks/useComments';
import { CommentItem } from './';

export const CommentList = ({ todoId }: { todoId: number }) => {
  const {
    query: { data: comments, isLoading },
  } = useComments({ todoId });

  if (isLoading) return <Spin />;

  return (
    <>
      <CommentAdd todoId={todoId} />
      <List bordered dataSource={comments} renderItem={comment => <CommentItem comment={comment} />} />
    </>
  );
};
