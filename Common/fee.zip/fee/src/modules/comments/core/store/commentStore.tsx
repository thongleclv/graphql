import { create } from 'zustand';

type CommentState = {
  thing: any;
};

type CommentAction = {
  setThing: (some: any) => void;
};

export const useCommentStore = create<CommentState & CommentAction>((set, get) => ({
  thing: false,
  setThing: (some: any) => {},
}));
