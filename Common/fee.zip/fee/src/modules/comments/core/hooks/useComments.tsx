import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { COMMENT_QUERY_KEYS } from '../constants';
import { Comment } from '../models';
import { addComment, getComments } from '../services';
import { TODO_QUERY_KEYS } from '@/src/modules/todos/core';

export const useComments = ({ todoId }: { todoId: number }) => {
  // Access the client
  const queryClient = useQueryClient();

  // Queries
  const query = useQuery<Comment[]>({
    queryKey: [COMMENT_QUERY_KEYS.COMMENTS, TODO_QUERY_KEYS.TODO, todoId],
    queryFn: (params: any) => getComments({ ...params, todoId }),
  });

  // Mutations
  const mutation = useMutation({
    mutationFn: (data: any) => addComment({ ...data, todoId }),
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: [COMMENT_QUERY_KEYS.COMMENTS, TODO_QUERY_KEYS.TODO, todoId],
      });
    },
  });

  return { query, mutation };
};
