export const VALIDATOR_PATTERNS = {
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/,
  email: /^!/,
  noVietnamese: /^!/,
  onlyLatin: /^!/,
  onlyNumber: /^!/,
};
