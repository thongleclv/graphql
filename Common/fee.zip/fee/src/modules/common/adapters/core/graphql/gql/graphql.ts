/* eslint-disable */
import { DocumentTypeDecoration } from '@graphql-typed-document-node/core';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string };
  String: { input: string; output: string };
  Boolean: { input: boolean; output: boolean };
  Int: { input: number; output: number };
  Float: { input: number; output: number };
};

export type Auth = {
  __typename?: 'Auth';
  accessToken: Scalars['String']['output'];
  refreshToken: Scalars['String']['output'];
};

export type CreateTodoDto = {
  description: Scalars['String']['input'];
  status: Scalars['String']['input'];
  title: Scalars['String']['input'];
};

export type LoginDto = {
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type ModifyTodoDto = {
  description?: InputMaybe<Scalars['String']['input']>;
  id: Scalars['String']['input'];
  status?: InputMaybe<Scalars['String']['input']>;
  title?: InputMaybe<Scalars['String']['input']>;
};

export type Mutation = {
  __typename?: 'Mutation';
  assignTodoToSelf: Scalars['Boolean']['output'];
  createTodo: Todo;
  deleteTodo: Scalars['Boolean']['output'];
  login: Auth;
  modifyTodo: Todo;
  signup: Auth;
};

export type MutationAssignTodoToSelfArgs = {
  id: Scalars['String']['input'];
};

export type MutationCreateTodoArgs = {
  body: CreateTodoDto;
};

export type MutationDeleteTodoArgs = {
  id: Scalars['String']['input'];
};

export type MutationLoginArgs = {
  body: LoginDto;
};

export type MutationModifyTodoArgs = {
  body: ModifyTodoDto;
};

export type MutationSignupArgs = {
  body: SignupDto;
};

export type Query = {
  __typename?: 'Query';
  profile: User;
  todo: Todo;
  todos: Array<Todo>;
  users: Array<User>;
};

export type QueryTodoArgs = {
  id: Scalars['String']['input'];
};

export type SignupDto = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  password: Scalars['String']['input'];
  username: Scalars['String']['input'];
};

export type Todo = {
  __typename?: 'Todo';
  assignee?: Maybe<User>;
  assigneer: User;
  createdAt: Scalars['Float']['output'];
  description: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  status: TodoStatus;
  title: Scalars['String']['output'];
  updatedAt: Scalars['Float']['output'];
};

/** This is status for TodoSchema */
export enum TodoStatus {
  Doing = 'DOING',
  Done = 'DONE',
  Pending = 'PENDING',
  Todo = 'TODO',
}

export type User = {
  __typename?: 'User';
  firstName: Scalars['String']['output'];
  fullName: Scalars['String']['output'];
  id: Scalars['String']['output'];
  lastName: Scalars['String']['output'];
  username: Scalars['String']['output'];
};

export type LoginMutationVariables = Exact<{
  body: LoginDto;
}>;

export type LoginMutation = {
  __typename?: 'Mutation';
  login: { __typename?: 'Auth'; accessToken: string; refreshToken: string };
};

export type SignupMutationVariables = Exact<{
  body: SignupDto;
}>;

export type SignupMutation = {
  __typename?: 'Mutation';
  signup: { __typename?: 'Auth'; accessToken: string; refreshToken: string };
};

export type CreateTodoMutationVariables = Exact<{
  body: CreateTodoDto;
}>;

export type CreateTodoMutation = {
  __typename?: 'Mutation';
  createTodo: {
    __typename?: 'Todo';
    createdAt: number;
    description: string;
    id: string;
    status: TodoStatus;
    title: string;
    updatedAt: number;
    assignee?: {
      __typename?: 'User';
      firstName: string;
      fullName: string;
      id: string;
      lastName: string;
      username: string;
    } | null;
    assigneer: {
      __typename?: 'User';
      firstName: string;
      fullName: string;
      id: string;
      lastName: string;
      username: string;
    };
  };
};

export type GetTodoQueryVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type GetTodoQuery = {
  __typename?: 'Query';
  todo: {
    __typename?: 'Todo';
    createdAt: number;
    description: string;
    id: string;
    status: TodoStatus;
    title: string;
    updatedAt: number;
  };
};

export type TodosQueryVariables = Exact<{ [key: string]: never }>;

export type TodosQuery = {
  __typename?: 'Query';
  todos: Array<{
    __typename?: 'Todo';
    createdAt: number;
    description: string;
    id: string;
    status: TodoStatus;
    title: string;
    updatedAt: number;
  }>;
};

export type DeleteTodoMutationVariables = Exact<{
  id: Scalars['String']['input'];
}>;

export type DeleteTodoMutation = { __typename?: 'Mutation'; deleteTodo: boolean };

export type ModifyTodoMutationVariables = Exact<{
  body: ModifyTodoDto;
}>;

export type ModifyTodoMutation = {
  __typename?: 'Mutation';
  modifyTodo: {
    __typename?: 'Todo';
    createdAt: number;
    description: string;
    id: string;
    status: TodoStatus;
    title: string;
    updatedAt: number;
  };
};

export class TypedDocumentString<TResult, TVariables>
  extends String
  implements DocumentTypeDecoration<TResult, TVariables>
{
  __apiType?: DocumentTypeDecoration<TResult, TVariables>['__apiType'];

  constructor(
    private value: string,
    public __meta__?: Record<string, any>,
  ) {
    super(value);
  }

  toString(): string & DocumentTypeDecoration<TResult, TVariables> {
    return this.value;
  }
}

export const LoginDocument = new TypedDocumentString(`
    mutation Login($body: LoginDto!) {
  login(body: $body) {
    accessToken
    refreshToken
  }
}
    `) as unknown as TypedDocumentString<LoginMutation, LoginMutationVariables>;
export const SignupDocument = new TypedDocumentString(`
    mutation Signup($body: SignupDto!) {
  signup(body: $body) {
    accessToken
    refreshToken
  }
}
    `) as unknown as TypedDocumentString<SignupMutation, SignupMutationVariables>;
export const CreateTodoDocument = new TypedDocumentString(`
    mutation CreateTodo($body: CreateTodoDto!) {
  createTodo(body: $body) {
    createdAt
    description
    id
    status
    title
    updatedAt
    assignee {
      firstName
      fullName
      id
      lastName
      username
    }
    assigneer {
      firstName
      fullName
      id
      lastName
      username
    }
  }
}
    `) as unknown as TypedDocumentString<CreateTodoMutation, CreateTodoMutationVariables>;
export const GetTodoDocument = new TypedDocumentString(`
    query getTodo($id: String!) {
  todo(id: $id) {
    createdAt
    description
    id
    status
    title
    updatedAt
  }
}
    `) as unknown as TypedDocumentString<GetTodoQuery, GetTodoQueryVariables>;
export const TodosDocument = new TypedDocumentString(`
    query Todos {
  todos {
    createdAt
    description
    id
    status
    title
    updatedAt
  }
}
    `) as unknown as TypedDocumentString<TodosQuery, TodosQueryVariables>;
export const DeleteTodoDocument = new TypedDocumentString(`
    mutation DeleteTodo($id: String!) {
  deleteTodo(id: $id)
}
    `) as unknown as TypedDocumentString<DeleteTodoMutation, DeleteTodoMutationVariables>;
export const ModifyTodoDocument = new TypedDocumentString(`
    mutation ModifyTodo($body: ModifyTodoDto!) {
  modifyTodo(body: $body) {
    createdAt
    description
    id
    status
    title
    updatedAt
  }
}
    `) as unknown as TypedDocumentString<ModifyTodoMutation, ModifyTodoMutationVariables>;
