import axios from 'axios';
import { config } from './config';
import { handleFailureRequest, handleFailureResponse, handleSuccessRequest, handleSuccessResponse } from './handler';

const httpClient = axios.create(config);

httpClient.interceptors.request.use(handleSuccessRequest, handleFailureRequest);

httpClient.interceptors.response.use(handleSuccessResponse, handleFailureResponse);

export { httpClient };
