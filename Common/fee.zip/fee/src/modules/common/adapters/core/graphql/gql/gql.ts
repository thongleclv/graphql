/* eslint-disable */
import * as types from './graphql';

/**
 * Map of all GraphQL operations in the project.
 *
 * This map has several performance disadvantages:
 * 1. It is not tree-shakeable, so it will include all operations in the project.
 * 2. It is not minifiable, so the string of a GraphQL query will be multiple times inside the bundle.
 * 3. It does not support dead code elimination, so it will add unused operations.
 *
 * Therefore it is highly recommended to use the babel or swc plugin for production.
 */
const documents = {
  '\n  mutation Login($body: LoginDto!) {\n    login(body: $body) {\n      accessToken\n      refreshToken\n    }\n  }\n':
    types.LoginDocument,
  '\n  mutation Signup($body: SignupDto!) {\n    signup(body: $body) {\n      accessToken\n      refreshToken\n    }\n  }\n':
    types.SignupDocument,
  '\n  mutation CreateTodo($body: CreateTodoDto!) {\n    createTodo(body: $body) {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n      assignee {\n        firstName\n        fullName\n        id\n        lastName\n        username\n      }\n      assigneer {\n        firstName\n        fullName\n        id\n        lastName\n        username\n      }\n    }\n  }\n':
    types.CreateTodoDocument,
  '\n  query getTodo($id: String!) {\n    todo(id: $id) {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n    }\n  }\n':
    types.GetTodoDocument,
  '\n  query Todos {\n    todos {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n    }\n  }\n':
    types.TodosDocument,
  '\n  mutation DeleteTodo($id: String!) {\n    deleteTodo(id: $id)\n  }\n': types.DeleteTodoDocument,
  '\n  mutation ModifyTodo($body: ModifyTodoDto!) {\n    modifyTodo(body: $body) {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n    }\n  }\n':
    types.ModifyTodoDocument,
};

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  mutation Login($body: LoginDto!) {\n    login(body: $body) {\n      accessToken\n      refreshToken\n    }\n  }\n',
): typeof import('./graphql').LoginDocument;
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  mutation Signup($body: SignupDto!) {\n    signup(body: $body) {\n      accessToken\n      refreshToken\n    }\n  }\n',
): typeof import('./graphql').SignupDocument;
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  mutation CreateTodo($body: CreateTodoDto!) {\n    createTodo(body: $body) {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n      assignee {\n        firstName\n        fullName\n        id\n        lastName\n        username\n      }\n      assigneer {\n        firstName\n        fullName\n        id\n        lastName\n        username\n      }\n    }\n  }\n',
): typeof import('./graphql').CreateTodoDocument;
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  query getTodo($id: String!) {\n    todo(id: $id) {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n    }\n  }\n',
): typeof import('./graphql').GetTodoDocument;
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  query Todos {\n    todos {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n    }\n  }\n',
): typeof import('./graphql').TodosDocument;
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  mutation DeleteTodo($id: String!) {\n    deleteTodo(id: $id)\n  }\n',
): typeof import('./graphql').DeleteTodoDocument;
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(
  source: '\n  mutation ModifyTodo($body: ModifyTodoDto!) {\n    modifyTodo(body: $body) {\n      createdAt\n      description\n      id\n      status\n      title\n      updatedAt\n    }\n  }\n',
): typeof import('./graphql').ModifyTodoDocument;

export function graphql(source: string) {
  return (documents as any)[source] ?? {};
}
