import { ProtectedLayout } from './protected';

export const SuperAdminLayout = ({ user, children }: any) => {
  const isAdmin = user && user.role === 'superadmin';
  return isAdmin ? <ProtectedLayout>{children}</ProtectedLayout> : null;
};
