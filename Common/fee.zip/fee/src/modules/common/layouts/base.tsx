import { ProtectedLayout } from './protected';
import { Layout1 } from './layout1';

export const BaseLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <ProtectedLayout>
      <Layout1>
        <>{children}</>
      </Layout1>
    </ProtectedLayout>
  );
};
