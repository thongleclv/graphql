import { Col, Flex, Row } from 'antd';
import Image from 'next/image';
import coverLogin from '@/public/images/cover-login-dark-1.png';

export const BlankLayout = ({ children }: { children: React.ReactNode }) => {
  return (
    <Row className="bg-[#F9FAFB]">
      <Col xs={0} sm={0} md={12} className="h-screen">
        <Flex className="h-full">
          <Image priority src={coverLogin} width={1000} height={1000} alt="cover_login" className="object-cover" />
        </Flex>
      </Col>
      <Col xs={24} sm={24} md={12} className="h-screen">
        {children}
      </Col>
    </Row>
  );
};
