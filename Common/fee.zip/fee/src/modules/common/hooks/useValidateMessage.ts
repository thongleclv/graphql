import { message, Typography } from 'antd';
export const useValidateMessages = () => {
  // const { translate } = useLocalization();

  const validateMessages = {
    required: "${label} is required!",
    // ...
  };

  return validateMessages;
};
