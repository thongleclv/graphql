/**
 * Generate a random string
 * @returns A random string
 */
export const makeRandomString = (): string => {
  return '';
};
