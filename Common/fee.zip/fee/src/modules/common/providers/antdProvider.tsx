import { ConfigProvider, type ThemeConfig } from '@/src/modules/common/components/ui';
import { createCache, extractStyle, StyleProvider } from '@ant-design/cssinjs';
import type Entity from '@ant-design/cssinjs/es/Cache';
import { useServerInsertedHTML } from 'next/navigation';
import React from 'react';
import { useValidateMessages } from '../hooks/useValidateMessage';
import { Typography } from 'antd/lib';

export const theme: ThemeConfig = {
  token: {},
  components: {
    Button: {
      // Radius
      borderRadius: 8,
      borderRadiusLG: 12,
      borderRadiusSM: 8,
      borderRadiusXS: 8,

      // Padding
      paddingBlockLG: '12px 16px',
      paddingInlineLG: '12px 16px',
      paddingBlock: '8px 12px',
      paddingInline: '8px 12px',
      paddingBlockSM: '4px 12px',
      paddingInlineSM: '4px 12px',

      //TypePrimary
      colorPrimaryBg: '#0060F6',
      colorPrimaryText: '#fff',
      colorPrimaryBgHover: '#4E8FF4',
      colorTextDisabled: '#858D9D',
      borderColorDisabled: '#D9D9D9',
      colorBgContainerDisabled: '#F5F5F5',

      //TypeSecondary
      defaultBg: '#FFFFFF',
      defaultBorderColor: '#D9D9D9',
      defaultColor: '#096DD9',

      //Destructive
      colorErrorBg: '#FF4D4F',
      colorErrorText: '#fff',
    },
  },
};

export const StyledComponentsRegistry = ({ children }: React.PropsWithChildren) => {
  const cache = React.useMemo<Entity>(() => createCache(), []);
  const isServerInserted = React.useRef<boolean>(false);
  useServerInsertedHTML(() => {
    // avoid duplicate css insert
    if (isServerInserted.current) {
      return;
    }
    isServerInserted.current = true;
    return <style id="antd" dangerouslySetInnerHTML={{ __html: extractStyle(cache, true) }} />;
  });
  return (
    <StyleProvider cache={cache} hashPriority="high">
      {children}
    </StyleProvider>
  );
};

export const AntdProvider = ({ children }: { children: React.ReactNode }) => {
  const validateMessages = useValidateMessages();
  return (
    <ConfigProvider
      theme={theme}
      form={{
        validateMessages,
      }}
    >
      <StyledComponentsRegistry>
        <>{children}</>
      </StyledComponentsRegistry>
    </ConfigProvider>
  );
};
