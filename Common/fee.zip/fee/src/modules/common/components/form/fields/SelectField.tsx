import { Form, Input } from '../../ui';

export const SelectField = (props: any) => {
  return (
    <Form.Item>
      <Input />
    </Form.Item>
  );
};
