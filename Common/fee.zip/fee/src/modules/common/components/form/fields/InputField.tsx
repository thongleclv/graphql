import { FormItemProps, InputProps, Form, Input } from 'antd';

export const InputField = ({ ...props }: FormItemProps & InputProps) => {
  const { size, rules } = props;
  const inputSize = {
    large: '',
    middle: 'px-4 py-2 rounded-lg body-t14r',
    small: 'px-2 py-1 body-t14r',
  };
  return (
    <Form.Item {...props} className='m-0' rules={rules}>
      <Input {...props} className={`${inputSize[size || 'middle']} ${props.className}`} />
    </Form.Item>
  );
};
