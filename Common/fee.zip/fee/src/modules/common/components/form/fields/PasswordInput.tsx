import { EyeInvisibleOutlined, EyeOutlined } from '@ant-design/icons';
import { Form, FormItemProps, Input, InputProps } from 'antd';

export const PasswordInput = ({ ...props }: FormItemProps & InputProps) => {
  const { size, validateStatus } = props;
  const inputSize = {
    large: '',
    middle: 'px-4 py-2 rounded-lg body-t14r',
    small: 'px-2 py-1 body-t14r',
  };
  return (
    <Form.Item {...props} className="m-0" validateStatus={validateStatus}>
      <Input.Password
        className={`${inputSize[size || 'middle']} ${props.className}`}
        iconRender={visible => (visible ? <EyeOutlined /> : <EyeInvisibleOutlined />)}
        visibilityToggle
      />
    </Form.Item>
  );
};
