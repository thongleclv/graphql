import { Breadcrumb } from 'antd';
import { BreadcrumbProps as AntBreadcrumbProps } from 'antd/lib/breadcrumb';

interface CustomBreadcrumbProps extends AntBreadcrumbProps {
  // Bổ sung các props tùy chọn mà bạn muốn thêm vào
  // Ví dụ:
  // customProp?: string;
  [key: string]: any;
}
export const CustomBreadcrumb = ({ title, menu, ...props }: CustomBreadcrumbProps) => {
  // const {t} = useTransition()

  return <Breadcrumb separator=">" items={[{ title: title, href: menu }]} {...props} />;
};
