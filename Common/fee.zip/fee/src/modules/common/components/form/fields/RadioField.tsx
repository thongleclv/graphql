import { Form, Radio, RadioChangeEvent } from 'antd';

interface RadioFieldProps {
  name: string;
  options: any[];
  onChange?: (event: RadioChangeEvent) => void;
  value?: any;
  checked?: boolean;
  labelKey?: string;
  label?: string;
  disabled?: boolean;
  required?: boolean;
  [key: string]: any;
}

export const RadioField = () => {
  return (
    <Form.Item>
      <Radio.Group>
        <Radio value="apple"> Apple </Radio>
      </Radio.Group>
    </Form.Item>
  );
};
