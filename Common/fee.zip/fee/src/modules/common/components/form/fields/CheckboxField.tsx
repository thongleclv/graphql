import { CheckboxChangeEvent } from 'antd/es/checkbox';
import { Checkbox, Form } from '../../ui';

interface CheckBoxProps {
  name: string;
  options: any[];
  onChange?: (event: CheckboxChangeEvent) => void;
  value?: any;
  checked?: boolean;
  labelKey?: string;
  label?: string;
  disabled?: boolean;
  required?: boolean;
  // valuePropName?: string;

  [key: string]: any;
}

export const CheckboxField = ({ onChange, name, labelKey, label, value, checked, ...props }: CheckBoxProps) => {
  return (
    <Form.Item name={name} valuePropName="checked" {...props}>
      <Checkbox>{label}</Checkbox>
    </Form.Item>
  );
};
