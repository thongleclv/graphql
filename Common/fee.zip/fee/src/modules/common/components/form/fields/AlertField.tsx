import { Alert } from 'antd';

export const AlertField = () => {
  return (
    <Alert
      message="Password must be at least 6 characters and include: Uppercase, lowercase, numeric, and special characters."
      type={status}
      showIcon
    />
  );
};
