import { Button, Form, FormItemProps } from 'antd';
import { ButtonProps } from 'antd/lib/button';

export const ButtonField = (props: ButtonProps & FormItemProps) => {
  const { size } = props;
  const buttonSize = {
    large: 'h-12 rounded-xl px-4 py-3 h4-t16m',
    middle: 'h-10 rounded-lg px-3 py-2 body-t14m',
    small: 'h-8 rounded-lg px-2 py-1 body-t14r',
  };
  return (
    <Form.Item className="m-0">
      <Button {...props} className={`${buttonSize[size || 'middle']} ${props.className}`}>
        {props.label}
      </Button>
    </Form.Item>
  );
};
