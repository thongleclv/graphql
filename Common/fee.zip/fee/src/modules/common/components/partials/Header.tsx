import { HeaderMenu } from './HeaderMenu';

export const Header = () => {
  return (
    <>
      <HeaderMenu />
    </>
  );
};
