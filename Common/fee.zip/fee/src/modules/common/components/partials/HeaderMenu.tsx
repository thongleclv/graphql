import { useAuth, useProfile } from '@/src/modules/auth/core/hooks';
import { HomeOutlined, LogoutOutlined, OrderedListOutlined, UserOutlined } from '@ant-design/icons';
import type { MenuProps } from 'antd';
import Link from 'next/link';
import { Menu } from '../ui';

export const HeaderMenu = () => {
  const {
    query: { data: profile },
  } = useProfile();
  const { authenticated } = useAuth();

  const items: MenuProps['items'] = [
    {
      label: <Link href="/">Home</Link>,
      key: 'home',
      icon: <HomeOutlined />,
    },
    {
      label: <Link href="/todos">Todo</Link>,
      key: 'todos',
      icon: <OrderedListOutlined />,
    },
  ];

  if (profile) {
    items.push({
      label: <Link href="/auth/profile">{profile?.username}</Link>,
      key: 'profile',
      icon: <UserOutlined />,
    });
  }

  if (authenticated) {
    items.push({
      label: <Link href="/auth/logout">Logout</Link>,
      key: 'logout',
      icon: <LogoutOutlined />,
    });
  }

  return (
    <>
      <Menu mode="inline" items={items} theme="dark" />
    </>
  );
};
