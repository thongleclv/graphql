export type UserProfile = {
  id: number;
  // firstName: string;
  // lastName: string;
  username: string;
  // avatar: string;
  createdAt: any;
  updatedAt: any;
  lastLogin: any;
  hashRefreshToken: string;
};

export type UserLogin = {
  username: string;
  password: string;
};

export type UserLoginReponse = {
  accessToken: string;
};

export type UserRegister = {
  firstName: string;
  lastName: string;
  username: string;
  password: string;
};

export type UserChangePassword = {
  id: number;
  password: string;
};

export type UserAudit = Omit<UserProfile, 'username'>;

export type Role = {
  code: string;
  name: string;
  permissions: [Permission];
};

export type Permission = {
  code: string;
  name: string;
};

export type UserRole = {
  role: Role;
};
