import { useMutation } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect } from 'react';
import { changePasswordService, loginService, logoutService, registerService } from '../services';
import { useAuthStore } from '../store';
import { useCookies } from 'react-cookie';
import { ChangeDefaultService } from '../services/changeDefaultPassword.service';

export const useLogin = ({
  onSuccess,
  onFailed,
}: {
  onSuccess?: (data: any) => void;
  onFailed?: (error: any) => void;
}) => {
  // const mutation = useGraphMutation<LoginMutation>(USER_LOGIN, {
  //   onCompleted: data => {
  //     onSuccess && onSuccess(data?.login.accessToken);
  //   },
  //   onError: onFailed,
  // });

  // return {
  //   mutate: (values: UserLogin) => {
  //     return mutation[0]({ variables: { body: values } });
  //   },
  //   ...mutation[1],
  // };

  // const [cookies, setCookie] = useCookies(['token']);
  // console.log('---cookies---', cookies);

  const mutation = useMutation({
    mutationFn: loginService,
    onSuccess: response => {
      // cookies().set('token', response?.login.accessToken);
      // cookies
      // setCookie('token', response?.login.accessToken);
      onSuccess && onSuccess(response?.login.accessToken);
    },
    onError: onFailed,
  });

  return mutation;
};

export const useRegister = ({
  onSuccess,
  onFailed,
}: {
  onSuccess?: (data: any) => void;
  onFailed?: (error: any) => void;
}) => {
  const mutation = useMutation({
    mutationFn: registerService,
    onSuccess: response => {
      onSuccess && onSuccess(response);
    },
    onError: onFailed,
  });

  return mutation;
};

export const useChangePassword = ({
  onSuccess,
  onFailed,
}: {
  onSuccess?: (data: any) => void;
  onFailed?: (error: any) => void;
}) => {
  const mutation = useMutation({
    mutationFn: changePasswordService,
    onSuccess: response => {
      onSuccess && onSuccess(response);
    },
    onError: onFailed,
  });

  return mutation;
};

export const useChangeDefaultPassword = ({
  onSuccess,
  onFailed,
}: {
  onSuccess?: (data: any) => void;
  onFailed?: (error: any) => void;
}

) => {
  const mutation = useMutation({
    mutationFn: ChangeDefaultService,
    onSuccess: response => {
      onSuccess && onSuccess(response);
      console.log('onsuccess');

    },
    onError: onFailed,
  })

  return mutation;
}


export const useLogout = ({ onSuccess, onFailed }: { onSuccess?: () => void; onFailed?: (error: any) => void }) => {
  const mutation = useMutation({
    mutationFn: logoutService,
    onSuccess: response => {
      onSuccess && onSuccess();
    },
    onError: onFailed,
  });

  return mutation;
};


export const useAuth = () => {
  const [cookies, setCookie, removeCookie] = useCookies(['token']);
  const router = useRouter();
  const store = useAuthStore();

  const login = useLogin({
    onSuccess: token => {
      setCookie('token', token);
      store.setAuthenticated(true);
      router.push('/');
    },
  });
  const register = useRegister({
    onSuccess: response => {
      router.push('/auth/login');
    },
  });
  const logout = useLogout({
    onSuccess: () => {
      // localStorage.removeItem('token');
      removeCookie('token');
      store.setAuthenticated(false);
      router.push('/auth/login');
    },
  });
  const changePassword = useChangePassword({});

  const changDefaultPassword = useChangeDefaultPassword({
    onSuccess: response => {
      if (response) {
        router.push('/auth/login');
      }
    }
  });

  // const forgetPassword = use;



  const hasPermission = useCallback((checkPermission: string | Array<string>): boolean => {
    return true;
    // const { permissions } = store;
    // return permissions.some((x) => checkPermission.includes(x));
    // return checkUserPermission(checkPermission);
  }, []);

  useEffect(() => {
    // const token = typeof window !== 'undefined' ? !!window.localStorage.getItem('token') : false;
    // if (token) store.setAuthenticated(true);

    if (cookies.token) store.setAuthenticated(true);
  }, []);

  return {
    ...store,
    login,
    register,
    logout,
    changePassword,
    changDefaultPassword,
    hasPermission,
  };
};
