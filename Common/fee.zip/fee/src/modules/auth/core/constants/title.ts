export const LOGIN_TITLE = 'CPS Where Data Drives Strategic Success!';
export const CHANGE_PASSWORD_TITLE = 'Change default password';
export const CHANGE_PASSWORD_DESCRIPTION = 'You must change your default password due to confidential data.';
