import { create } from "zustand";
import { LOGIN_TITLE } from "..";

type LoginState = {
  type: 'login' | 'change-password';
  title: string;
  description: string | null;
  isFirstLogin: boolean;
};

type LoginAction = {
  setType: (type: 'login' | 'change-password') => void;
  setTitle: (title: string) => void;
  setDescription: (description: string) => void;
  setIsFirstLogin: (isFirstLogin: boolean) => void;
};



export const useLoginStore = create<LoginState & LoginAction>((set, get) => ({
    type: 'login',
    title: LOGIN_TITLE,
    description: null,
    isFirstLogin: false,
    setType: (type: 'login' | 'change-password') => set(() => ({ type })),
    setTitle: (title: string) => set(() => ({ title })),
    setDescription: (description: string) => set(() => ({ description })),
    setIsFirstLogin: (isFirstLogin: boolean) => set(() => ({ isFirstLogin })),
}));