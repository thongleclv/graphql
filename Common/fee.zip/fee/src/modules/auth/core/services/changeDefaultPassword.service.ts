import { LoginMutation } from '@/src/modules/common/adapters/core/graphql/gql/graphql';
import { UserLogin } from '../models';
import { graphClient } from '@/src/modules/common/adapters/core';
import { gql } from '@apollo/client';

// const LOGIN_MUTATION = gql(/* GraphQL */ `
//   mutation ChangeDefaultPassword($body: ChangeDefaultPasswordDto!) {
//     changeDefaultPassword(body: $body) {
//       success
//       error
//     }
//   }
// `);

export const ChangeDefaultService = async (data: UserLogin): Promise<any> => {
  // const response = await graphClient.mutate({
  //   mutation: LOGIN_MUTATION,
  //   variables: { body: data },
  // });
  // return response.data;

  return {
    changeDefaultPassword: {
      success: true,
      error: null,
    },
  }
};
