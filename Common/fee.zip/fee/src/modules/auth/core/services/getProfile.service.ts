import { graphql } from '@/src/modules/common/adapters/core/graphql/gql';
import { UserProfile } from '..';

// const getProfileQueryDocument = graphql(/* GraphQL */ `
//   query getProfile {
//     own {
//       id
//       username
//       createDate
//       updatedDate
//       lastLogin
//       hashRefreshToken
//     }
//   }
// `);

// export const getProfileService = async (): Promise<UserProfile> => {
//   const response = await fetchClient<GetProfileQuery, any>(getProfileQueryDocument, {});
//   return response.own;
// };
