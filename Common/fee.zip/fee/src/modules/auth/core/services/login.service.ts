import { LoginMutation } from '@/src/modules/common/adapters/core/graphql/gql/graphql';
import { UserLogin } from '../models';
import { graphClient } from '@/src/modules/common/adapters/core';
import { gql } from '@apollo/client';

const LOGIN_MUTATION = gql(/* GraphQL */ `
  mutation Login($body: LoginDto!) {
    login(body: $body) {
      accessToken
      refreshToken
    }
  }
`);

export const loginService = async (data: UserLogin): Promise<LoginMutation> => {
  const response = await graphClient.mutate({
    mutation: LOGIN_MUTATION,
    variables: { body: data },
  });
  return response.data;
};
