import React from 'react';
import { Flex, Typography } from '@/src/modules/common/components/ui';
import { FormItemProps } from 'antd';

import { CheckCircleFilled, CloseCircleFilled, InfoCircleFilled } from '@ant-design/icons';

export const HintWrapper = ({ hint, status }: { hint: string| undefined ; status: FormItemProps['validateStatus'] }) => {
  return (
    <Flex gap={4} justify="start" align="start" >
      {status === undefined && <InfoCircleFilled style={{ color: '#C2C6CE' }} className="pt-1" />}
      {status === 'error' && <CloseCircleFilled style={{ color: '#FF4D4F' }} className="pt-1" />}
      {status === 'success' && <CheckCircleFilled style={{ color: '#52C41A' }} className="pt-1" />}

      <Typography.Text className="body-t14r text-dark-60">{hint}</Typography.Text>
    </Flex>
  );
};
