import { Button, Flex, Form } from '@/src/modules/common/components/ui';
import { useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useChangePassword } from '../hooks/useAuth';
import { UserChangePassword } from '../models';
import { PasswordField } from './fields';
import { ConfirmPasswordField } from './fields/ConfirmPasswordField';
import { LabelLayout } from './login-flow/miscellaneous';
import { ButtonField } from '@/src/modules/common/components/form';
import { Alert } from 'antd/lib';
import { CONFIRM_PASSWORD_HINT, NEW_PASSWORD_HINT } from '../constants/inputHint';

export const ChangePasswordForm = () => {
  // const queryClient = useQueryClient();

  const [error, setError] = useState<any>();

  const [form] = Form.useForm();
  const router = useRouter();

  const changePassword = useChangePassword({
    onFailed: setError,
    onSuccess: () => router.push('/auth/login'),

    // onSuccess: data => {
    //   const queryKey: QueryKey = ['yourUserDataQueryKey'];
    //   queryClient.invalidateQueries(queryKey, data);
    // },
  });

  const onFinish = (values: UserChangePassword) => {
    console.log('Success:', values);

    changePassword.mutate(values);
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <Form
      form={form}
      name="basic"
      layout="vertical"
      initialValues={{ remember: true }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      autoComplete="off"
      className="flex w-full flex-col gap-6"
    >
      <Flex className="w-full" vertical gap={16}>
        <PasswordField name="newPassword" label={<LabelLayout required>{'New password'}</LabelLayout>} size="middle" />
        <ConfirmPasswordField name="confirmPassword" label={<LabelLayout required>{'Confirm new password'}</LabelLayout>} size="middle"/>
      </Flex>

      <ButtonField label={'Save'} type="primary" htmlType="submit" block />
    </Form>
  );
};
