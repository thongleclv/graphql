import { Unauthorized } from '.';
import { useAuth } from '../hooks';

export const PermissionGate = ({
  children,
  permissions,
  variant = 'default',
}: {
  children: React.ReactNode;
  permissions: string | Array<string>;
  variant: 'default' | 'hidden' | 'retry';
}) => {
  const { hasPermission } = useAuth();

  const permissionGranted = hasPermission(permissions);

  if (!permissionGranted) {
    if (variant === 'hidden') return <></>;
    if (variant === 'retry') return <>Retry</>;
    return <Unauthorized />;
  }

  return <>{children}</>;
};
