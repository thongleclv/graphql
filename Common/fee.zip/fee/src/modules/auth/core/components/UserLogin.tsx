import { ButtonField } from '@/src/modules/common/components/form';
import { Flex, Form, FormInstance } from '@/src/modules/common/components/ui';
import { useAuth } from '../hooks/useAuth';
import { UserLogin } from '../models';
import { useLoginStore } from '../store';
import { PasswordField, UsernameField } from './fields';
import { LabelLayout } from './login-flow';

export const LoginForm = () => {
  const { setType } = useLoginStore();

  const [form] = Form.useForm();

  const {
    login: { mutate: loginMutation, isPending: isLoadingLogin, error },
  } = useAuth();

  const onFinish = (values: UserLogin) => {
    loginMutation(values);
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <Form
      form={form}
      initialValues={{ remember: true }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      autoComplete="off"
      className="flex w-full flex-col gap-6"
      layout="vertical"
      requiredMark={false}
    >
      <Flex className="w-full" vertical gap={16}>
        <UsernameField name="username" label={<LabelLayout>{'Username'}</LabelLayout>} size="middle" />
        <PasswordField name="password" label={<LabelLayout>{'Password'}</LabelLayout>} size="middle" />
      </Flex>
      <ButtonField
        name="login"
        label={'Login'}
        type="primary"
        htmlType="submit"
        loading={isLoadingLogin}
        size="middle"
        block
      />
    </Form>
  );
};
