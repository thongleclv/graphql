import { PasswordInput } from '@/src/modules/common/components/form';
import { FormItemProps, InputProps } from 'antd';
import { Fragment, useEffect, useState } from 'react';
import { HintWrapper } from '../login-flow';
import { CONFIRM_PASSWORD_HINT } from '../../constants/inputHint';

export const ConfirmPasswordField = (props: FormItemProps & InputProps) => {
  const [status, setStatus] = useState<FormItemProps['validateStatus']>();

  const validateConfirmPassword = (_: any, value: string) => {
    const password = (props.form as any)?.getFieldValue('newPassword');
    if (value !== password) {
      setStatus('error');
    } else {
      setStatus('success');
    }
  };
  useEffect(() => {
    setStatus(undefined);
  }, [(props.form as any)?.getFieldValue('newPassword')]);

  return (
    <Fragment>
      <PasswordInput
        dependencies={['newPassword']}
        validateStatus={status}
        rules={[{ validator: validateConfirmPassword }, ...(props.rules || [])]}
        {...props}
      />
      {/* {props.showHint && <HintWrapper status={status} hint={props.hint ? props.hint : undefined} />} */}
      {props.name === 'confirmPassword' && <HintWrapper status={status} hint={CONFIRM_PASSWORD_HINT} />}
    </Fragment>
  );
};
