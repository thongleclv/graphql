import { Form } from '@/src/modules/common/components/ui';
import { useEffect, useState } from 'react';
import { PasswordField } from './fields';
import { LabelLayout } from './login-flow/miscellaneous';
import { ButtonField } from '@/src/modules/common/components/form';
import { SuperAdminLayout } from '@/src/modules/common/layouts/superAdminLayout';

export const UserForgotPassword = () => {
  const [currentUserRole, setCurrentUserRole] = useState('superadmin');

  const [form] = Form.useForm();

  // const token = cookies.get('token');

  useEffect(() => {
    // Fetch user role here, maybe from a context or API call
    const fetchedUserRole = 'superadmin'; // Fetch user role
    setCurrentUserRole(fetchedUserRole);
  }, []);

  return (
    <Form
      form={form}
      name="basic"
      layout="vertical"
      initialValues={{ remember: true }}
      // onFinish={onFinish}
      // onFinishFailed={onFinishFailed}
      autoComplete="off"
      style={{ width: '100%', marginTop: '0rem !important' }}
      // labelCol={{ span: 4 }}
      // wrapperCol={{ span: 14 }}
      size="middle"
    >
      <SuperAdminLayout userRole={currentUserRole}>
        <h1>Forgot Password</h1>
        <PasswordField className="mb-4" name="password" label={<LabelLayout>{'Password'}</LabelLayout>} />
        <ButtonField label={'Change Password'} type="primary" htmlType="submit" block />
      </SuperAdminLayout>
    </Form>
  );
};
