import { Fragment } from 'react';
import { LeftOutlined } from '@ant-design/icons';
import Link from 'next/link';
import { Typography } from 'antd';
import { useLoginStore } from '../../../store';

export const BackNavigation = () => {
  const { setType } = useLoginStore();
  return (
    <Typography.Text
      onClick={() => setType('login')}
      className="h4-t16r flex cursor-pointer justify-start gap-2 text-dark-80 hover:bg-slate-300"
    >
      <LeftOutlined />
      Back
    </Typography.Text>
  );
};
