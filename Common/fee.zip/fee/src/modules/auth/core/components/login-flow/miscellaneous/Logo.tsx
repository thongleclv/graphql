import Image, { StaticImageData } from "next/image";

export const Logo = ({ src }: { src: StaticImageData }) => {
    return (
      <Image
        priority
        src={src}
        width={100}
        height={100}
        alt="cover_login"
        className="aspect-square rounded-full object-cover"
      />
    );
  };
  