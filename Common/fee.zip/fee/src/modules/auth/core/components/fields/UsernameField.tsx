import { InputField } from '@/src/modules/common/components/form';
import { FormItemProps, InputProps } from 'antd';

export const UsernameField = (props: InputProps & FormItemProps) => {
  return (
    <InputField
      rules={[
        {
          required: true,
        },
      ]}
      {...props}
    />
  );
};
