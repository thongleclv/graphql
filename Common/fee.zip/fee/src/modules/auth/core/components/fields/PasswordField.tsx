import { PasswordInput } from '@/src/modules/common/components/form';
import { VALIDATOR_PATTERNS } from '@/src/modules/common/constants/validatorPatterns';
import { FormItemProps, InputProps } from 'antd';
import { Fragment, useState } from 'react';
import { HintWrapper } from '../login-flow';
import { NEW_PASSWORD_HINT } from '../../constants/inputHint';

export const PasswordField = (props: FormItemProps & InputProps) => {
  const [status, setStatus] = useState<FormItemProps['validateStatus']>();
  const { name } = props;

  const validatePassword = async (_: any, value: string) => {
    const isValidPassword = VALIDATOR_PATTERNS.password.test(value);
    if (!value || !isValidPassword) {
      setStatus('error'); // Set status to error if the password doesn't meet the pattern
    } else {
      setStatus('success'); // Set status to success if all validations pass
    }
    return Promise.resolve();
  };

  return (
    <Fragment>
      <PasswordInput
        validateStatus={status}
        rules={[
          {
            validator: validatePassword,
          },
          ...(props.rules || []),
        ]}
        {...props}
      />
      {/* {hint && <HintWrapper status={status} hint={hint ? hint : undefined} />} */}
      {name === 'newPassword' && <HintWrapper status={status} hint={NEW_PASSWORD_HINT} />}
    </Fragment>
  );
};
