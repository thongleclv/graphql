import { Typography } from '@/src/modules/common/components/ui';

export const DescriptionChangePassword = ({ description }: { description: string | null }) => {
  return (
    description !== null && (
      <Typography.Text className="h4-t16r text-start text-dark-80/40">{description}</Typography.Text>
    )
  );
};
