import { ButtonField } from '@/src/modules/common/components/form';
import { Button, Result } from '@/src/modules/common/components/ui';
import { useRouter } from 'next/navigation';

export const Unauthenticated = () => {
  const router = useRouter();

  return (
    <Result
      status="403"
      title="403"
      subTitle="Sorry, you are not authorized to access this page."
      extra={
        <ButtonField label={'Login'} type="primary" onClick={() => router.push('/auth/login')}>
          Login
        </ButtonField>
      }
    />
  );
};
