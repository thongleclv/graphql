import { Unauthenticated } from '.';
import { useAuth } from '../hooks';

export const Protected = ({ children }: { children: React.ReactNode }) => {
  const { authenticated } = useAuth();

  if (!authenticated) return <Unauthenticated />;

  return <>{children}</>;
};
