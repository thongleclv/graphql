import { Typography } from '@/src/modules/common/components/ui';
export const LabelLayout = ({ children, required }: { children: React.ReactNode; required?: boolean }) => {
  return (
    <Typography.Text className="subtitle-t12m pb-1 text-dark-60">
      {children}
      {required && <span className="text-red-500 body-t14r ms-0.5">*</span>}
    </Typography.Text>
  );
};
