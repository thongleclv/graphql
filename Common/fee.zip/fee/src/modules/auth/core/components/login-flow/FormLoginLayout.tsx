import logo from '@/public/images/cover-login-dark-1.png';
import { Flex, Typography } from '@/src/modules/common/components/ui';
import { ChangePasswordForm, LoginForm } from '..';
import { useLoginStore } from '../../store';
import { BackNavigation, DescriptionChangePassword, Logo } from './miscellaneous';

export const FormLoginLayout = () => {
  const loginStore = useLoginStore();
  const { type, title, description } = loginStore;

  return (
    <Flex className="h-full items-center lg:items-start lg:py-20" justify="center">
      <Flex className="max-w-sm" vertical gap={64}>
        <Flex>{type == 'change-password' && <BackNavigation />}</Flex>
        <Flex vertical gap={40}>
          <Flex justify="center">{type === 'login' && <Logo src={logo} />}</Flex>
          <Flex vertical gap={16}>
            <Typography.Text className={`${type === 'change-password' ? 'text-start' : 'text-center'} h2-t30s`}>
              {title}
            </Typography.Text>
            {type === 'change-password' && <DescriptionChangePassword description={description} />}
          </Flex>
          <Flex>{type === 'login' && <LoginForm />}</Flex>
          <Flex>{type === 'change-password' && <ChangePasswordForm />}</Flex>
        </Flex>
      </Flex>
    </Flex>
  );
};
