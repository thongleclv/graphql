import { ChangePasswordForm } from '../core/components/UserChangePassword';

export default function ChangePasswordPage() {
  return (
    <>
      <h1>Change password</h1>

      <ChangePasswordForm />
    </>
  );
}
