import { BlankLayout } from '../common/layouts';

const AuthLayout = ({ children }: { children: React.ReactNode }) => {
  return <BlankLayout>{children}</BlankLayout>;
};

export default AuthLayout;
