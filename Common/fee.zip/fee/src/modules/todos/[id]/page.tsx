import { TodoDetail } from '../core/components';

export default function TodoPage({ params }: { params: { id: number } }) {
  return (
    <>
      <h1>Todo item {params.id}</h1>

      <TodoDetail todoId={params.id} />
    </>
  );
}
