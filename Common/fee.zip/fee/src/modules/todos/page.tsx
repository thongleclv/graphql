import { Col, Row, Space } from '@/src/modules/common/components/ui';
import Link from 'next/link';
import { TodoList } from './core/components';

export default function TodosPage() {
  return (
    <>
      <h1>Todo List</h1>
      <TodoList />
    </>
  );
}
