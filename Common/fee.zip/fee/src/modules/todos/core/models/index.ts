import { UserAudit } from '@/src/modules/auth/core/models';
import { BaseEntity } from '@/src/modules/common/models';

export type Todo = BaseEntity & {
  title: string;
  status: string;
  description?: string;

  assignee?: UserAudit;
  assigner?: UserAudit;
};

export type TodoForCreation = Pick<Todo, 'title' | 'description' | 'status'>;

export type TodoForUpdating = Pick<Todo, 'id' | 'title' | 'description' | 'status'>;
