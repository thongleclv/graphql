import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { TODO_QUERY_KEYS } from '../constants';
import { Todo } from '../models';
import { addTodoService, getTodoService, updateTodoService } from '../services';
import { deleteTodoService } from '../services/removeTodo.service';

export const useTodo = ({ todoId }: { todoId?: string }) => {
  // Access the client
  const queryClient = useQueryClient();

  // Queries
  const query = useQuery<Todo | undefined>({
    queryKey: [TODO_QUERY_KEYS.TODOS, todoId],
    queryFn: async (): Promise<Todo> => {
      if (todoId) return await getTodoService(todoId);
      throw new Error('No todo id provided');
    },
  });

  // Mutations
  const edit = useMutation({
    mutationFn: updateTodoService,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: [TODO_QUERY_KEYS.TODOS, todoId],
      });
    },
  });

  const add = useMutation({
    mutationFn: addTodoService,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: [TODO_QUERY_KEYS.TODOS, todoId],
      });
    },
  });

  const remove = useMutation({
    mutationFn: deleteTodoService,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: [TODO_QUERY_KEYS.TODOS, todoId],
      });
    },
  });

  return { query, edit, add, remove };
};
