import { useRouter } from 'next/navigation';
import { useTodo } from '../hooks';
import { TodoForCreation } from '../models';
import { TodoForm } from './TodoForm';

export const TodoAdd = () => {
  const { add } = useTodo({});
  const router = useRouter();

  const onFinish = (values: TodoForCreation) => {
    add.mutate(
      { ...values },
      {
        onSuccess: (data, variables, context) => {
          router.push('/todos');
        },
      },
    );
  };

  return <TodoForm onFinish={onFinish} status={add} />;
};
