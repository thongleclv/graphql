// import { CommentList } from "@/src/comments/core";
import { useLocalization } from '@/src/modules/common';
import { Button, Descriptions } from '@/src/modules/common/components/ui';
import { EditOutlined } from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import { useTodo } from '../hooks';

export const TodoDetail = ({ todoId }: { todoId: string }) => {
  const {
    query: { data: todo },
  } = useTodo({ todoId });

  const { formatDateTime } = useLocalization();

  const router = useRouter();

  const items = [
    {
      label: 'Title',
      children: todo?.title,
    },
    {
      label: 'Status',
      children: todo?.status ? 'Done' : 'Active',
    },
    // {
    //   label: "Assignee",
    //   children: todo?.assignee,
    // },
    // {
    //   label: "Description",
    //   children: todo?.description,
    // },
    {
      label: 'Created at',
      children: formatDateTime(todo?.createdAt),
    },
    // {
    //   label: "Created by",
    //   children: todo?.createdBy,
    // },
    {
      label: 'Updated at',
      children: formatDateTime(todo?.updatedAt),
    },
    // {
    //   label: "Updated by",
    //   children: todo?.updatedBy,
    // },
  ];

  return (
    <>
      <Button
        type="primary"
        onClick={() => router.push(`/todos/${todoId}/edit`)}
        icon={<EditOutlined />}
        className="mb-[1rem]"
      >
        Edit
      </Button>
      <Descriptions bordered column={1} items={items} />
      {/* <CommentList todoId={todoId} /> */}
    </>
  );
};
