import { Button, List, Modal } from '@/src/modules/common/components/ui';
import Link from 'next/link';
import { Todo } from '../models';
import { ExclamationCircleFilled } from '@ant-design/icons';

interface TodoItemProps {
  todo: Todo;
  handleDelete: (id: string) => void;
}

export const TodoItem = ({ todo, handleDelete }: TodoItemProps) => {
  const showConfirm = (todo: Todo) => {
    Modal.confirm({
      title: `Do you want to delete this todo ${todo.title}? `,
      icon: <ExclamationCircleFilled />,
      content: 'Some descriptions',
      onOk() {
        handleDelete(todo.id);
      },
      onCancel() {
        // console.log('Cancel');
      },
    });
  };
  return (
    <List.Item
      actions={[
        <Button type="dashed" key="edit">
          <Link href={`/todos/${todo.id}/edit`}>Edit</Link>
        </Button>,
        <Button type="dashed" key="view">
          <Link href={`/todos/${todo.id}`}>View</Link>
        </Button>,
        <Button
          type="primary"
          danger
          key="view"
          onClick={() => {
            showConfirm(todo);
          }}
        >
          Delete
        </Button>,
      ]}
    >
      <List.Item.Meta
        // avatar={<Avatar src={todo?.assigner?.avatar} />}
        title={
          <>
            <Link href={`/todos/${todo.id}`}>{todo.title}</Link>
          </>
        }
        description={
          <>
            {/* <p>Description: {todo.description}</p> */}
            <p>Status: {todo.status}</p>
            {/* <p>Assignee: {todo.assignee}</p> */}
          </>
        }
      />
    </List.Item>
  );
};
