export enum TODO_QUERY_KEYS {
  TODO = 'TODO',
  TODOS = 'TODOS',
}
