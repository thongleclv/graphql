import { AntdProvider, ReactQueryProviders } from '@/src/modules/common/providers';
import type { NextPage } from 'next';
import type { AppProps } from 'next/app';
import { useEffect, useState, type ReactElement, type ReactNode } from 'react';
import { GraphQLProvider } from '../modules/common/providers/graphQLProvider';
import './globals.css';

export type NextPageWithLayout<P = {}, IP = P> = NextPage<P, IP> & {
  getLayout?: (page: ReactElement) => ReactNode;
};

type AppPropsWithLayout = AppProps & {
  Component: NextPageWithLayout;
};

export default function MyApp({ Component, pageProps }: AppPropsWithLayout) {
  const [ready, setReady] = useState<boolean>(false);

  useEffect(() => {
    setReady(true);
  }, []);

  if (!ready) return <></>;

  // Use the layout defined at the page level, if available
  const getLayout = Component.getLayout ?? (page => page);

  return <RootLayout pageProps={pageProps}>{getLayout(<Component {...pageProps} />)}</RootLayout>;
}

function RootLayout({ children, pageProps }: { children: React.ReactNode; pageProps?: unknown }) {
  return (
    <GraphQLProvider>
      <ReactQueryProviders pageProps={pageProps}>
        <AntdProvider>
          <>{children}</>
        </AntdProvider>
      </ReactQueryProviders>
    </GraphQLProvider>
  );
}
