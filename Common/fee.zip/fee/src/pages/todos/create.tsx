import { BaseLayout } from '@/src/modules/common/layouts';
import { TodoAdd } from '@/src/modules/todos/core/components';
import { ReactElement } from 'react';

export default function CreatePage() {
  return (
    <>
      <h1>Create Todo item</h1>

      <TodoAdd />
    </>
  );
}

CreatePage.getLayout = (page: ReactElement) => {
  return <BaseLayout>{page}</BaseLayout>;
};
