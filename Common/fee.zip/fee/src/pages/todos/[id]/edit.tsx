import { BaseLayout } from '@/src/modules/common/layouts';
import { TodoEdit } from '@/src/modules/todos/core/components';
import { NextApiRequest } from 'next';
import { useRouter } from 'next/router';
import { ReactElement, useState } from 'react';

export default function EditTodoPage({ id }: { id: string }) {
  // const router = useRouter();
  // const { id: idTodo } = router.query;

  const [todoTitle, setTodoTitle] = useState('');

  return (
    <>
      <h1>Todo item {todoTitle ?? id}</h1>

      <TodoEdit todoId={id} setTodoTitle={setTodoTitle} />
    </>
  );
}

EditTodoPage.getLayout = (page: ReactElement) => {
  return <BaseLayout>{page}</BaseLayout>;
};

export async function getServerSideProps(req: NextApiRequest) {
  // const queryClient = new QueryClient();

  // await queryClient.prefetchQuery({
  //   queryKey: ['todos'],
  //   queryFn: ({ queryKey }) => getTodosApi({ queryKey }),
  // });

  return {
    props: {
      id: req.query.id,
      // dehydratedState: dehydrate(queryClient),
    },
  };
}
