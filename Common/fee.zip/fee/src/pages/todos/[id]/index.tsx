import { BaseLayout } from '@/src/modules/common/layouts';
import { TodoDetail } from '@/src/modules/todos/core/components';
import { NextApiRequest } from 'next';
import { ReactElement } from 'react';

export default function TodoDetailPage({ id }: { id: string }) {
  return (
    <>
      <h1>Todo item {id}</h1>

      <TodoDetail todoId={id} />
    </>
  );
}

TodoDetailPage.getLayout = (page: ReactElement) => {
  return <BaseLayout>{page}</BaseLayout>;
};

export async function getServerSideProps(req: NextApiRequest) {
  // const queryClient = new QueryClient();

  // await queryClient.prefetchQuery({
  //   queryKey: ['todos'],
  //   queryFn: ({ queryKey }) => getTodosApi({ queryKey }),
  // });

  return {
    props: {
      id: req.query.id,
      // dehydratedState: dehydrate(queryClient),
    },
  };
}
