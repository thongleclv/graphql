import { Typography } from '@/src/modules/common/components/ui';
import { BaseLayout } from '@/src/modules/common/layouts';
import { TodoList } from '@/src/modules/todos/core/components';
import { ReactElement } from 'react';

const { Title } = Typography;

export default function TodosPage() {
  return (
    <>
      <Title>Todo List</Title>
      <TodoList />
    </>
  );
}

TodosPage.getLayout = (page: ReactElement) => {
  return <BaseLayout>{page}</BaseLayout>;
};
