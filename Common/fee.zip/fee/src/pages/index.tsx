import { BaseLayout } from '@/src/modules/common/layouts';
// import { QueryClient, dehydrate } from '@tanstack/react-query';
import { ReactElement } from 'react';
import { Typography } from '@/src/modules/common/components/ui';

const { Title } = Typography;

export default function Page() {
  return (
    <>
      <Title>Hello todo app !!!</Title>
    </>
  );
}

Page.getLayout = function getLayout(page: ReactElement) {
  return <BaseLayout>{page}</BaseLayout>;
};

// export async function getServerSideProps() {
//   const queryClient = new QueryClient();

//   await queryClient.prefetchQuery({
//     queryKey: ['posts', 10],
//     queryFn: () => [],
//   });

//   return {
//     props: {
//       dehydratedState: dehydrate(queryClient),
//     },
//   };
// }
