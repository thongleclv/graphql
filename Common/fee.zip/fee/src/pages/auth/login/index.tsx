import { FormLoginLayout } from '@/src/modules/auth/core/components/login-flow';
import { BlankLayout } from '@/src/modules/common/layouts';
import { ReactElement } from 'react';

export default function LoginPage() {
  return <FormLoginLayout />;
}

LoginPage.getLayout = (page: ReactElement) => {
  return <BlankLayout>{page}</BlankLayout>;
};
