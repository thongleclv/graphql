import { UserForgotPassword, UserLogout } from '@/src/modules/auth/core/components';
import { BlankLayout } from '@/src/modules/common/layouts';
import { ReactElement } from 'react';

export default function ForgotPasswordPage() {
  return (
    <>
      <UserForgotPassword />
    </>
  );
}

ForgotPasswordPage.getLayout = (page: ReactElement) => {
  return <BlankLayout>{page}</BlankLayout>;
};
