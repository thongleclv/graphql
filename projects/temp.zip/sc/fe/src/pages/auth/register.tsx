import { RegisterForm } from '@/src/modules/auth/core/components';
import { BlankLayout } from '@/src/modules/common/layouts';
import { ReactElement } from 'react';

export default function RegisterPage() {
  return (
    <>
      <h1>Register</h1>
      <RegisterForm />
    </>
  );
}

RegisterPage.getLayout = (page: ReactElement) => {
  return <BlankLayout>{page}</BlankLayout>;
};
