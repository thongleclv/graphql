import { LoginForm } from '@/src/modules/auth/core/components';
import { Typography } from '@/src/modules/common/components/ui';
import { BlankLayout } from '@/src/modules/common/layouts';
import { ReactElement } from 'react';

const { Title } = Typography;

export default function LoginPage() {
  return (
    <>
      <Title>Login</Title>
      <LoginForm />
    </>
  );
}

LoginPage.getLayout = (page: ReactElement) => {
  return <BlankLayout>{page}</BlankLayout>;
};
