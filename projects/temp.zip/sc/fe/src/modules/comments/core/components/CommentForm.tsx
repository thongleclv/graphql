import { Alert, Button, Form, Input } from '@/src/modules/common/components/ui';
import { UseMutationResult } from '@tanstack/react-query';
import { Comment, CommentForCreation } from '../models';

const { TextArea } = Input;

export const CommentForm = ({
  initialValues,
  onFinish,
  status,
}: {
  initialValues?: object;
  onFinish?: (values: any) => void;
  status: UseMutationResult<Comment, Error, any, unknown>;
}) => {
  const [form] = Form.useForm();

  return (
    <>
      {/* <Button
        type="primary"
        onClick={() => form.submit()}
        className="mb-[1rem]"
        loading={status.isPending}
      >
        Submit
      </Button> */}
      {status.error && <Alert message={status.error.message} type="error" className="mb-[1rem]" />}
      {/* {status.isSuccess && (
        <Alert message="Success" type="success" className="mb-[1rem]" />
      )} */}
      <Form
        form={form}
        layout="horizontal"
        style={{ maxWidth: 600 }}
        initialValues={initialValues}
        onFinish={onFinish}
        autoComplete="off"
      >
        <Form.Item<CommentForCreation> name="content">
          <TextArea rows={5} />
        </Form.Item>
        <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
          <Button loading={status.isPending} type="primary" htmlType="submit">
            Submit
          </Button>
        </Form.Item>
      </Form>
    </>
  );
};
