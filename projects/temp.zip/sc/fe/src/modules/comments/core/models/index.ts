import { BaseEntity } from '@/src/modules/common/models';

export type Comment = BaseEntity & {
  content: string;
  todoId: number;
};

export type CommentForCreation = Omit<Comment, 'id' | 'createdAt' | 'updatedAt' | 'createdBy' | 'updatedBy'>;

export type CommentForUpdating = Omit<Comment, 'createdAt' | 'updatedAt' | 'createdBy' | 'updatedBy'> &
  Partial<Pick<Comment, 'id'>>;
