import { core } from '@/src/modules/common/adapters';
import { Comment, CommentForCreation, CommentForUpdating } from '../models';

export const getComments = async (query: any): Promise<Comment[]> => {
  const response = await core.httpClient.get(`/todo/${query.todoId}/comment`, { params: query });
  return response.data;
};

export const getComment = async (id: number): Promise<Comment> => {
  const response = await core.httpClient.get(`/comment/${id}`);
  return response.data;
};

export const addComment = async (comment: CommentForCreation): Promise<Comment> => {
  const response = await core.httpClient.post(`/todo/${comment.todoId}/comment`, comment);
  return response.data;
};

export const updateComment = async (comment: CommentForUpdating): Promise<Comment> => {
  const response = await core.httpClient.patch('/comment', comment);
  return response.data;
};
