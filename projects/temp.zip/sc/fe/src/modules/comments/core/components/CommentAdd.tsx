import { useComments } from '../hooks';
import { CommentForCreation } from '../models';
import { CommentForm } from './CommentForm';

export const CommentAdd = ({ todoId }: { todoId: number }) => {
  const { mutation } = useComments({ todoId });

  const onFinish = (values: CommentForCreation) => {
    mutation.mutate({ ...values, todoId });
  };

  return <CommentForm onFinish={onFinish} status={mutation} />;
};
