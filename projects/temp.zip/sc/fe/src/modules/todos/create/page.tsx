import { TodoAdd } from '../core/components';

export default function TodoAddPage() {
  return (
    <>
      <h1>Create Todo item</h1>

      <TodoAdd />
    </>
  );
}
