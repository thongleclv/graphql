import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { TODO_QUERY_KEYS } from '../constants';
import { Todo } from '../models';
import { addTodoService, getTodosService } from '../services';

export const useTodos = () => {
  // Access the client
  const queryClient = useQueryClient();

  // Queries
  const query = useQuery<Todo[]>({
    queryKey: [TODO_QUERY_KEYS.TODOS],
    queryFn: getTodosService,
  });

  // Mutations
  const mutation = useMutation({
    mutationFn: addTodoService,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: [TODO_QUERY_KEYS.TODOS] });
    },
  });

  return { query, mutation };
};
