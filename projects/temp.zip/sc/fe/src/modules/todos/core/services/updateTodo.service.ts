import { graphClient } from '@/src/modules/common/adapters/core';
import { Todo, TodoForUpdating } from '../models';
import { gql } from '@apollo/client';

const UPDATE_TODO_MUTATION = gql`
  mutation ModifyTodo($body: ModifyTodoDto!) {
    modifyTodo(body: $body) {
      createdAt
      description
      id
      status
      title
      updatedAt
    }
  }
`;

export const updateTodoService = async (todo: TodoForUpdating): Promise<Todo> => {
  const response = await graphClient.mutate({
    mutation: UPDATE_TODO_MUTATION,
    variables: { body: todo },
  });
  return response.data;
};
