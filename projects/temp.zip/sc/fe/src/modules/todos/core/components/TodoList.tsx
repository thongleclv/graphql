import { Button, Col, Input, List, Row, Spin } from '@/src/modules/common/components/ui';
import { PlusOutlined } from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import { useTodos } from '../hooks/useTodos';
import { TodoItem } from './TodoItem';
import { useTodo } from '../hooks';
import { ChangeEvent, useState } from 'react';
import { Todo } from '../models';

export const TodoList = () => {
  const router = useRouter();
  const [search, setSearch] = useState('');

  const {
    query: { data: todos, isLoading },
  } = useTodos();

  const { remove } = useTodo({});

  const handleDelete = (id: string) => {
    remove.mutate(id);
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
  };

  const filterTodos = (todos: Todo[] | undefined) => {
    return (todos && todos.filter(todo => todo.title.indexOf(search) !== -1)) ?? [];
  };

  if (isLoading) return <Spin />;

  return (
    <>
      <Row gutter={10}>
        <Col span={22}>
          <Input placeholder="Search something" onChange={handleInputChange} />
        </Col>
        <Col span={2}>
          <Button
            type="primary"
            onClick={() => router.push('/todos/create')}
            icon={<PlusOutlined />}
            className="mb-[1rem]"
          >
            Create
          </Button>
        </Col>
      </Row>
      <List
        style={{ background: 'white', marginTop: 10 }}
        bordered
        dataSource={filterTodos(todos)}
        renderItem={todo => <TodoItem todo={todo} handleDelete={handleDelete} />}
      />
    </>
  );
};
