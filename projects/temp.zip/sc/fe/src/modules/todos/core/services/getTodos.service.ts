import { graphql } from '@/src/modules/common/adapters/core/graphql/gql';
import { Todo } from '../models';
import request from 'graphql-request';
import { TodosQuery } from '@/src/modules/common/adapters/core/graphql/gql/graphql';

const getTodosQueryDocument = graphql(/* GraphQL */ `
  query Todos {
    todos {
      createdAt
      description
      id
      status
      title
      updatedAt
    }
  }
`);

export const getTodosService = async (query: any): Promise<Todo[]> => {
  const result = await request<TodosQuery>('/api', getTodosQueryDocument.toString());
  return result.todos;
};
