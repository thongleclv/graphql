import { Alert, Button, Checkbox, Form, Input, InputNumber, Select } from '@/src/modules/common/components/ui';
import { UseMutationResult } from '@tanstack/react-query';
import { TodoForUpdating } from '../models';
import { TodoStatus } from '@/src/modules/common/adapters/core/graphql/gql/graphql';

const { TextArea } = Input;

export const TodoForm = ({
  initialValues,
  onFinish,
  status,
}: {
  initialValues?: TodoForUpdating;
  onFinish?: (values: any) => void;
  status: UseMutationResult<TodoForUpdating, Error, any, unknown>;
}) => {
  const [form] = Form.useForm();

  const options = Object.values(TodoStatus).map(status => ({
    label: status,
    value: status.toLocaleLowerCase(),
  }));

  return (
    <>
      <Button type="primary" onClick={() => form.submit()} className="mb-[1rem]" loading={status.isPending}>
        Submit
      </Button>
      {status.error && <Alert message={status.error.message} type="error" className="mb-[1rem]" />}
      {status.isSuccess && <Alert message="Success" type="success" className="mb-[1rem]" />}
      <Form
        form={form}
        layout="vertical"
        style={{ maxWidth: 600 }}
        initialValues={initialValues}
        onFinish={onFinish}
        autoComplete="off"
      >
        <Form.Item<TodoForUpdating> label="Title" name="title" rules={[{ required: true }]}>
          <Input />
        </Form.Item>
        <Form.Item<TodoForUpdating> label="Description" name="description" rules={[{ required: true }]}>
          <TextArea rows={5} />
        </Form.Item>
        <Form.Item<TodoForUpdating> label="Status" name="status" rules={[{ required: true }]}>
          {/* <Checkbox /> */}
          <Select options={options} />
        </Form.Item>
        {initialValues && (
          <>
            <Form.Item<TodoForUpdating> label="Id" name="id" rules={[{ required: true }]} hidden>
              <InputNumber hidden />
            </Form.Item>
          </>
        )}
        {/* <Form.Item<UpdateTodoMutation["updateTodo"]>
          label="Description"
          name="description"
        >
          <TextArea rows={5} />
        </Form.Item> */}
        {/* <Form.Item<UpdateTodoMutation["updateTodo"]>
          label="Assignee (id)"
          name="assignee"
          rules={[{ required: true }]}
        >
          <Input />
        </Form.Item> */}
        {/* <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item> */}
      </Form>
    </>
  );
};
