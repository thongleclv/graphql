import { create } from 'zustand';

type TodoState = {
  thing: any;
};

type TodoAction = {
  setThing: (some: any) => void;
};

export const useTodoStore = create<TodoState & TodoAction>((set, get) => ({
  thing: false,
  setThing: (some: any) => {},
}));
