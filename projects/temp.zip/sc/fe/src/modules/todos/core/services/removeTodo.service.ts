import { graphClient } from '@/src/modules/common/adapters/core';
import { gql } from '@apollo/client';

const DELETE_TODO_MUTATION = gql`
  mutation DeleteTodo($id: String!) {
    deleteTodo(id: $id)
  }
`;

export const deleteTodoService = async (id: string) => {
  const response = await graphClient.mutate({
    mutation: DELETE_TODO_MUTATION,
    variables: { id },
  });
  return response.data;
};
