import { graphql } from '@/src/modules/common/adapters/core';
import { GetTodoQuery } from '@/src/modules/common/adapters/core/graphql/gql/graphql';
import request from 'graphql-request';
import { Todo } from '../models';

const getTodoQueryDocument = graphql(/* GraphQL */ `
  query getTodo($id: String!) {
    todo(id: $id) {
      createdAt
      description
      id
      status
      title
      updatedAt
    }
  }
`);

export const getTodoService = async (id: string): Promise<Todo> => {
  const result = await request<GetTodoQuery>('/api', getTodoQueryDocument.toString(), { id });
  return result.todo;
};
