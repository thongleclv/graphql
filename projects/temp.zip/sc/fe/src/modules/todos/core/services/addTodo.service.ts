import { graphClient } from '@/src/modules/common/adapters/core';
import { Todo, TodoForCreation } from '../models';
import { gql } from '@apollo/client';

const ADD_TODO_MUTATION = gql`
  mutation CreateTodo($body: CreateTodoDto!) {
    createTodo(body: $body) {
      createdAt
      description
      id
      status
      title
      updatedAt
      assignee {
        firstName
        fullName
        id
        lastName
        username
      }
      assigneer {
        firstName
        fullName
        id
        lastName
        username
      }
    }
  }
`;

export const addTodoService = async (todo: TodoForCreation): Promise<Todo> => {
  const response = await graphClient.mutate({
    mutation: ADD_TODO_MUTATION,
    variables: { body: todo },
  });
  return response.data;
};
