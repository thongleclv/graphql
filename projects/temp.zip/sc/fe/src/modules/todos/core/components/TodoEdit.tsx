import { Spin } from '@/src/modules/common/components/ui';
import { useTodo } from '../hooks';
import { TodoForUpdating } from '../models';
import { TodoForm } from './TodoForm';
import { Dispatch, SetStateAction, useEffect } from 'react';

interface TodoEditProps {
  todoId: string;
  setTodoTitle: Dispatch<SetStateAction<string>>;
}

export const TodoEdit = ({ todoId, setTodoTitle }: TodoEditProps) => {
  const {
    query: { data: todo, isLoading },
    edit,
  } = useTodo({ todoId });

  const onFinish = (values: TodoForUpdating) => {
    edit.mutate({ ...values, id: todoId });
  };

  useEffect(() => {
    setTodoTitle(todo?.title ?? '');
  }, [todo]);

  if (isLoading) return <Spin />;

  return <TodoForm onFinish={onFinish} initialValues={todo} status={edit} />;
};
