import { TodoEdit } from '../../core/components';

export default function TodoEditPage({ params }: { params: { id: number } }) {
  return (
    <>
      <h1>Edit Todo item {params.id}</h1>

      <TodoEdit todoId={params.id} />
    </>
  );
}
