import { BaseLayout } from '../common/layouts';

export default BaseLayout;
