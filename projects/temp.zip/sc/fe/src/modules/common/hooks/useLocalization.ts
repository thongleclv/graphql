export const useLocalization = () => {
  return {
    language: 'vi',
    locale: 'vi',
    changeLanguage: (language: string): string => language,
    formatNumber: (number: number): string => number.toString(),
    formatDateTime: (date?: Date | number): string => {
      if (date) {
        const d = new Date(date);
        return d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
      }
      return '-';
    },
    formatCurrency: (number: number): string => number.toString(),
  };
};
