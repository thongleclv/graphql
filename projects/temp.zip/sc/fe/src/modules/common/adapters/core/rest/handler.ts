export const handleSuccessRequest = async (config: any) => {
  config.headers.Authorization = `Bearer ${localStorage.getItem('token')}`;
  return config;
};

export const handleFailureRequest = (error: any) => {
  return Promise.reject(error);
};

export const handleSuccessResponse = (response: any) => {
  return response;
};

export const handleFailureResponse = (error: any) => {
  return Promise.reject(error);
};
