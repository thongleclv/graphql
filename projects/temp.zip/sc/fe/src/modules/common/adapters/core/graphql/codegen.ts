import { CodegenConfig } from '@graphql-codegen/cli';

const configCodegen: CodegenConfig = {
  schema: process.env.API_URL,
  documents: ['src/modules/**/*', '!src/modules/common/adapters/core/graphql/gql/**/*'],
  ignoreNoDocuments: true, // for better experience with the watcher
  generates: {
    'src/modules/common/adapters/core/graphql/gql/': {
      preset: 'client',
      config: {
        documentMode: 'string',
      },
    },
  },
  watch: true,
  hooks: { afterAllFileWrite: ['prettier --write'] },
};

export default configCodegen;
