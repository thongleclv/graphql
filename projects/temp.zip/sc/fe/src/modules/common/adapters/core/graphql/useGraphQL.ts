import { useQuery } from '@tanstack/react-query';
import { config } from './config';
import { TypedDocumentString } from './gql/graphql';

export const useGraphQL = <TResult, TVariables>(
  document: TypedDocumentString<TResult, TVariables>,
  ...[variables]: TVariables extends Record<string, never> ? [] : [TVariables]
) => {
  return useQuery<TResult>({
    queryKey: [document.toString(), variables],
    queryFn: async ({ queryKey }) => {
      const response = await fetch(config.baseURL, {
        method: 'POST',
        headers: config.headers,
        body: JSON.stringify({
          query: document.toString(),
          variables: queryKey[1],
        }),
      });

      const json = await response.json();

      const result = json.data as TResult;

      return result;
    },
  });
};
