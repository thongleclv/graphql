import axios from 'axios';

const apiClient = axios.create({
  headers: {
    'Content-Type': 'application/json',
  },
});

const handleSuccessRequest = async (config: any) => {
  // config.headers.Authorization = `Bearer ${localStorage.getItem('token')}`;
  return config;
};

const handleFailureRequest = (error: any) => {
  return Promise.reject(error);
};

const handleSuccessResponse = (response: any) => {
  return response.data;
};

const handleFailureResponse = (error: any) => {
  return Promise.reject(error);
};

apiClient.interceptors.request.use(handleSuccessRequest, handleFailureRequest);

apiClient.interceptors.response.use(handleSuccessResponse, handleFailureResponse);

export { apiClient };
