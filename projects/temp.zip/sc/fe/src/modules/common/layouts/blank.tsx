export const BlankLayout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};
