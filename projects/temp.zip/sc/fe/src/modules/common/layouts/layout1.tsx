import { Header } from '@/src/modules/common/components/partials';
import { Layout } from '@/src/modules/common/components/ui';
import { useState } from 'react';

const { Content, Footer, Sider } = Layout;

export const Layout1 = ({ children }: { children: React.ReactNode }) => {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <>
      <Layout style={{ minHeight: '100vh' }}>
        <Sider collapsible collapsed={collapsed} onCollapse={value => setCollapsed(value)}>
          {/* <div className="demo-logo-vertical" /> */}
          <Header />
        </Sider>
        <Layout>
          <Content style={{ margin: '0 16px' }}>{children}</Content>
          <Footer style={{ textAlign: 'center' }}>OM3 POOL - Team 2 - Practices</Footer>
        </Layout>
      </Layout>
    </>
  );
};
