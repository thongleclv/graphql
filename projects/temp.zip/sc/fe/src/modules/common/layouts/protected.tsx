import { Protected } from '@/src/modules/auth/core/components';

export const ProtectedLayout = ({ children }: { children: React.ReactNode }) => {
  return <Protected>{children}</Protected>;
};
