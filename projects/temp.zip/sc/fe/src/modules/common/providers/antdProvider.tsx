import { createCache, extractStyle, StyleProvider } from '@ant-design/cssinjs';
import type Entity from '@ant-design/cssinjs/es/Cache';
import type { ThemeConfig } from 'antd';
import { ConfigProvider } from 'antd';
import { useServerInsertedHTML } from 'next/navigation';
import React from 'react';

export const theme: ThemeConfig = {
  // token: {
  // fontSize: 16,
  // colorPrimary: "#52c41a",
  // },
};

export const StyledComponentsRegistry = ({ children }: React.PropsWithChildren) => {
  const cache = React.useMemo<Entity>(() => createCache(), []);
  const isServerInserted = React.useRef<boolean>(false);
  useServerInsertedHTML(() => {
    // avoid duplicate css insert
    if (isServerInserted.current) {
      return;
    }
    isServerInserted.current = true;
    return <style id="antd" dangerouslySetInnerHTML={{ __html: extractStyle(cache, true) }} />;
  });
  return (
    <StyleProvider cache={cache} hashPriority="high">
      {children}
    </StyleProvider>
  );
};

export const AntdProvider = ({ children }: { children: React.ReactNode }) => {
  return (
    <ConfigProvider theme={theme}>
      <StyledComponentsRegistry>
        <>{children}</>
      </StyledComponentsRegistry>
    </ConfigProvider>
  );
};
