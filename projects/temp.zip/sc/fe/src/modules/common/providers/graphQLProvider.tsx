import { ApolloProvider } from '@apollo/client';
import { ReactNode } from 'react';
import { graphClient } from '../adapters/core/graphql';

export const GraphQLProvider = ({ children }: { children: ReactNode }) => {
  return (
    <ApolloProvider client={graphClient}>
      <>{children}</>
    </ApolloProvider>
  );
};
