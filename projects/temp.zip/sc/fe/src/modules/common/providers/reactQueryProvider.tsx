import { HydrationBoundary, QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { useState } from 'react';
// import { ReactQueryStreamedHydration } from '@tanstack/react-query-next-experimental';

export const ReactQueryProviders = (props: { children: React.ReactNode; pageProps?: any }) => {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 5 * 1000,
          },
        },
      }),
  );

  return (
    <QueryClientProvider client={queryClient}>
      <HydrationBoundary state={props?.pageProps?.dehydratedState}>
        {/* <Component {...pageProps} /> */}
        {props.children}
      </HydrationBoundary>
      {/* <ReactQueryStreamedHydration>{props.children}</ReactQueryStreamedHydration> */}
      {/* {<ReactQueryDevtools initialIsOpen={false} />} */}
    </QueryClientProvider>
  );
};
