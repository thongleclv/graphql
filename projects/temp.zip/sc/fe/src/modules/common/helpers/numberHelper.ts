/**
 * Generate a random number
 * @returns A random number
 */
export const makeRandomNumber = (): number => {
  return 1;
};
