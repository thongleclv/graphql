import { UserLogout } from '../core/components/UserLogout';

export default function LogoutPage() {
  return (
    <>
      <UserLogout />
    </>
  );
}
