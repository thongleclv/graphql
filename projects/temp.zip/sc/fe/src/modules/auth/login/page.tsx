import { LoginForm } from '../core/components/UserLogin';

export default function LoginPage() {
  return (
    <>
      <h1>Login</h1>

      <LoginForm />
    </>
  );
}
