import { graphClient } from '@/src/modules/common/adapters/core';
import { UserLoginReponse, UserRegister } from '../models';
import { gql } from '@apollo/client';

const REGISTER_MUTATION = gql`
  mutation Signup($body: SignupDto!) {
    signup(body: $body) {
      accessToken
      refreshToken
    }
  }
`;

export const registerService = async (data: UserRegister): Promise<UserLoginReponse> => {
  const response = await graphClient.mutate({
    mutation: REGISTER_MUTATION,
    variables: { body: data },
  });
  return response.data;
};
