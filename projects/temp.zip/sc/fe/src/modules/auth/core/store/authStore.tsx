import { create } from 'zustand';

type AuthState = {
  authenticated: boolean;
  permissions: Array<string>;
};

type AuthAction = {
  setAuthenticated: (authenticated: boolean) => void;
};

export const useAuthStore = create<AuthState & AuthAction>((set, get) => ({
  authenticated: false,
  permissions: [],
  setAuthenticated: (authenticated: boolean) => set(() => ({ authenticated })),
}));
