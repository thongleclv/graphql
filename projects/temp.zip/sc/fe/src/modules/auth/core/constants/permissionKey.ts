export const PERRMISSION_KEY = {
  LOGIN: 'login',
  CREATE_USER: 'create_user',
};
