export const ROLE_KEY = {
  ADMIN: 'admin',
  GUEST: 'guest',
};
