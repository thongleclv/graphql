import { useEffect } from 'react';
import { useAuth } from '../hooks';

export const UserLogout = () => {
  const {
    logout: { mutate: logoutMutation },
  } = useAuth();

  useEffect(() => {
    logoutMutation({});
  }, []);

  return <>Logging out...</>;
};
