import { graphql } from '@/src/modules/common/adapters/core/graphql/gql';

// const logoutUserQueryDocument = graphql(/* GraphQL */ `
//   query logoutUser {
//     logout
//   }
// `);

export const logoutService = async (query?: any) => {
  // if (cookies().has('token')) {
  //   cookies().delete('token');
  // }
  return 'success';

  // const response = await fetchClient<LogoutUserQuery, LogoutUserQueryVariables>(logoutUserQueryDocument, {});
  // if (!!response.logout && cookies().has('token')) {
  //   cookies().delete('token');
  // }
  // return response.logout;
  // return core.httpClient.get("/logout");
};
