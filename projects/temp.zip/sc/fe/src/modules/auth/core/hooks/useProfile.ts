import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { USER_QUERY_KEYS } from '../constants';
import { getProfileService, updateProfileService } from '../services';

export const useProfile = () => {
  // Access the client
  const queryClient = useQueryClient();

  // Queries
  const query = useQuery({
    queryKey: [USER_QUERY_KEYS.GET_PROFILE],
    queryFn: () => getProfileService(),
  });

  // Mutations
  const mutation = useMutation({
    mutationFn: updateProfileService,
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({
        queryKey: [USER_QUERY_KEYS.GET_PROFILE],
      });
    },
  });

  return { query, mutation };
};
