// import { UserRole } from '../models';

import { NextRequest } from 'next/server';

export * from './changePassword.service';
export * from './getProfile.service';
export * from './login.service';
export * from './logout.service';
export * from './register.service';
export * from './updateProfile.service';

export const validateToken = (token: string): boolean => true;

export const isAuthenticated = (request: NextRequest) => {
  const token = request.cookies.get('token');
  return !!token;
};

// export const checkUserPermission = (checkPermissions: string | string[]): boolean => {
//   if (!isAuthenticated()) return false;

//   // const hasUser = cookies().has('user');
//   // if (!hasUser) return false;

//   // const user = cookies().get('user')?.value;
//   // if (!user) return false;

//   const userRole = JSON.parse(user) as UserRole;

//   return userRole.role.permissions.some(x => {
//     if (Array.isArray(checkPermissions)) {
//       return checkPermissions.some(y => y === x.code);
//     }
//     return checkPermissions.includes(x.code);
//   });
// };
