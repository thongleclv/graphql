export enum USER_QUERY_KEYS {
  GET_PROFILE = 'GET_PROFILE',
  LOGIN = 'LOGIN',
}
