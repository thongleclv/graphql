import { core } from '@/src/modules/common/adapters';
import { UserProfile } from '../models';

export const updateProfileService = async (data: UserProfile): Promise<UserProfile> => {
  return core.httpClient.post('/auth/updateProfile', data);
};
