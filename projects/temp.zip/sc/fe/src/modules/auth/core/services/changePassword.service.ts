import { core } from '@/src/modules/common/adapters';
import { UserChangePassword, UserProfile } from '../models';

export const changePasswordService = async (data: UserChangePassword): Promise<UserProfile> => {
  return core.httpClient.post('/auth/changePassword', data);
};
