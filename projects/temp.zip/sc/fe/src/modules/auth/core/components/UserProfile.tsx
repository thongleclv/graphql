import { useProfile } from '../hooks';

export const UserProfile = () => {
  const {
    query: { data: info },
  } = useProfile();

  return <>Hello there!! {info?.username}</>;
};
