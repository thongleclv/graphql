import { Alert, Button, Form, Input } from '@/src/modules/common/components/ui';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useChangePassword } from '../hooks/useAuth';
import { UserChangePassword } from '../models';

export const ChangePasswordForm = () => {
  // TODO
  // Check user have not been logged in but have a valid token
  // Check url for the first visit page

  const [error, setError] = useState<any>();
  const [form] = Form.useForm();
  const router = useRouter();

  const changePassword = useChangePassword({
    onFailed: setError,
    onSuccess: () => router.push('/auth/login'),
  });

  const onFinish = (values: UserChangePassword) => {
    console.log('Success:', values);

    changePassword.mutate(values);
  };

  const onFinishFailed = (errorInfo: any) => {
    console.log('Failed:', errorInfo);
  };

  type FieldType = {
    password?: string;
    confirmPassword?: string;
  };

  return (
    <Form
      form={form}
      name="basic"
      labelCol={{ span: 8 }}
      wrapperCol={{ span: 16 }}
      style={{ maxWidth: 600 }}
      initialValues={{ remember: true }}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      autoComplete="off"
    >
      <Form.Item<FieldType>
        label="Password"
        name="password"
        rules={[{ required: true, message: 'Please input your password!' }]}
      >
        <Input />
      </Form.Item>

      <Form.Item<FieldType>
        label="Confirm password"
        name="confirmPassword"
        rules={[{ required: true, message: 'Please input your confirm password!' }]}
      >
        <Input.Password />
      </Form.Item>

      {error && <Alert message={error?.message || error?.text} type="error" />}

      <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
  );
};
