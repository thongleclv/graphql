import { RegisterForm } from '../core/components/UserRegister';

export default function RegisterPage() {
  return (
    <>
      <h1>Register</h1>

      <RegisterForm />
    </>
  );
}
