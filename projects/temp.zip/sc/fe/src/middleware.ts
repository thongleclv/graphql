import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';

export const config = {
  matcher: '/((?!_next/static|_next/image|favicon.ico|auth).*)',
};
// let tick = 1;
export async function middleware(request: NextRequest) {
  // console.log(`----middleware: ${tick++}`, request.cookies);

  // Clone the request headers
  // You can modify them with headers API: https://developer.mozilla.org/en-US/docs/Web/API/Headers
  const requestHeaders = new Headers(request.headers);

  const token = request.cookies.get('token')?.value;
  if (token) requestHeaders.set('Authorization', `Bearer ${token}`);

  // Delete an existing request header
  // requestHeaders.delete('x-from-client');

  // You can also set request headers in NextResponse.rewrite
  return NextResponse.next({
    request: {
      // New request headers
      headers: requestHeaders,
    },
  });
}
