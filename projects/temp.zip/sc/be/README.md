npx husky add .husky/pre-commit 'yarn run lint'

npx husky add .husky/commit-msg 'npx commitlint --edit $1'

## Migrations

### Run

```
npm run db:migration:run
```

### Generate

```
npm run db:migration:generate --name=InitDb
```

### Create

```
npm run db:migration:create
```

### Revert

```
npm run db:migration:revert
```
