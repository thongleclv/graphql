#!/bin/sh
ts-node -r tsconfig-paths/register ./node_modules/typeorm/cli migration:create src/infrastructure/databases/migrations/$1
