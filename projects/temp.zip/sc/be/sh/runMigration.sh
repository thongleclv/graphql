#!/bin/sh
ts-node -r tsconfig-paths/register ./node_modules/typeorm/cli -d ./ormconfig.ts migration:run