import { DataSource, DataSourceOptions } from 'typeorm';
import { config as dotenvConfig } from 'dotenv';

dotenvConfig({ path: '.env' });

type DB_TYPE = 'postgres' | 'mysql';

export const configDB: DataSourceOptions = {
  type: `${(process.env.DB_TYPE as DB_TYPE) || 'postgres'}`,
  host: `${process.env.DB_HOST}`,
  port: +`${parseInt(process.env.DB_PORT, 10) ?? 3001}`,
  username: `${process.env.DB_USERNAME}`,
  password: `${process.env.DB_PASSWORD}`,
  database: `${process.env.DB_NAME}`,
  synchronize: false,
  logging: true,
  entities: ['src/infrastructure/databases/postgres/entities/*.entity.ts'],
  migrations: ['src/infrastructure/databases/migrations/*.ts'],
  migrationsTableName: 'Migrations',
  migrationsRun: true,
};

const dataSource = new DataSource(configDB);

export default dataSource;
