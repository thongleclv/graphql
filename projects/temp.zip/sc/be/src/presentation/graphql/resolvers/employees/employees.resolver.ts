import { Inject } from '@nestjs/common';
import { Resolver, Mutation } from '@nestjs/graphql';
import { EMPLOYEE_RESOLVER, PublicDecorator } from '@presentation/graphql/common';
import { UseCasesProxyModule } from '@infrastructure/useCasesProxy';
import { ImportEmloyeesUseCase } from '@application/useCases';
import { EmployeesSchema } from './employees.schema';

@Resolver(() => EmployeesSchema)
export class EmployeesResolver {
  constructor(
    @Inject(UseCasesProxyModule.IMPORT_EMPLOYEES)
    private readonly importEmloyeesUseCase: ImportEmloyeesUseCase,
  ) {}

  @PublicDecorator()
  @Mutation(() => [EmployeesSchema], { name: EMPLOYEE_RESOLVER.IMPORT_EMPLOYEES })
  async importEmployees() {
    /** TODOS: Use convertData functions */
    const employeeData = [
      {
        employeeName: 'Donnie Wolf',
        country: 'india',
        employeeCode: '255555',
        startDate: new Date(),
        endDate: new Date(),
        status: 'Inactive',
        accountId: 'hieuvo',
      },
      {
        employeeName: 'Myrtle Hansen',
        country: 'india',
        employeeCode: '271598',
        startDate: new Date(),
        endDate: new Date(),
        status: 'Inactive',
        accountId: 'huypham',
      },
    ];
    const employees = await this.importEmloyeesUseCase.execute(employeeData);
    return employees;
  }
}
