import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType('User')
export class UsersSchema {
  @Field()
  id: string;

  @Field()
  username: string;

  static normalize(user: UsersSchema) {
    return {
      id: user?.id,
      username: user?.username,
    };
  }
}
