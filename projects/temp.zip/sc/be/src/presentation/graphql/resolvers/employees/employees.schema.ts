import { Field, ID, ObjectType } from '@nestjs/graphql';

@ObjectType('Employee')
export class EmployeesSchema {
  @Field(() => ID)
  id: string;

  @Field()
  employeeName: string;

  @Field()
  country: string;

  @Field()
  employeeCode: number;

  @Field()
  startDate: Date;

  @Field()
  endDate: Date;

  @Field()
  status: string;

  @Field()
  createdAt: Date;

  @Field()
  updatedAt: Date;

  static normalize(employee: EmployeesSchema) {
    return {
      id: employee?.id,
      employeeName: employee?.employeeName,
      country: employee?.country,
      employeeCode: employee?.employeeCode,
      startDate: employee?.startDate,
      endDate: employee?.endDate,
    };
  }
}
