import { Field, ID, ObjectType, registerEnumType } from '@nestjs/graphql';
import { UsersSchema } from '../users/users.schema';

export enum TodoStatus {
  TODO = 'todo',
  DOING = 'doing',
  PENDING = 'pending',
  DONE = 'done',
}

registerEnumType(TodoStatus, {
  name: 'TodoStatus',
  description: 'This is status for TodoSchema',
});

@ObjectType('Todo')
export class TodosSchema {
  @Field(() => ID)
  id: string;

  @Field()
  title: string;

  @Field()
  description: string;

  @Field(() => TodoStatus)
  status: string;

  @Field(() => UsersSchema)
  assignee: string;

  @Field(() => UsersSchema)
  assigneer: string;

  @Field(() => Number)
  createdAt: Date;

  @Field(() => Number)
  updatedAt: Date;

  static normalize(todo: TodosSchema) {
    return {
      id: todo.id,
      title: todo.title,
      description: todo.description,
      status: todo.status,
      assignee: todo.assignee,
      assigneer: todo.assigneer,
      createdAt: +todo.createdAt,
      updatedAt: +todo.updatedAt,
    };
  }
}
