import { Resolver, ResolveField, Parent, Mutation, Args, Query } from '@nestjs/graphql';
import { Inject } from '@nestjs/common';
import { User } from '@domain/entities';
import {
  CreateTodoUseCase,
  GetListTodoUseCase,
  GetTodoUseCase,
  ModifyTodoUseCase,
  RemoveTodoUseCase,
  GetUserUseCase,
} from '@application/useCases';
import { UseCasesProxyModule } from '@infrastructure/useCasesProxy';
import { UserDecorator, UserIdDecorator, TODO_RESOLVER, UuidV4Decorator } from '@presentation/graphql/common';
import { CreateTodoDto, ModifyTodoDto } from './todos.dto';
import { TodosSchema } from './todos.schema';
import { UsersSchema } from '../users/users.schema';

@Resolver(() => TodosSchema)
export class TodosResolver {
  constructor(
    @Inject(UseCasesProxyModule.CREATE_TODO_USECASE)
    private readonly createTodoUseCase: CreateTodoUseCase,
    @Inject(UseCasesProxyModule.GET_LIST_TODO_USECASE)
    private readonly getListTodoUseCase: GetListTodoUseCase,
    @Inject(UseCasesProxyModule.GET_TODO_USECASE)
    private readonly getTodoUseCase: GetTodoUseCase,
    @Inject(UseCasesProxyModule.MODIFY_TODO_USECASE)
    private readonly modifyTodoUseCase: ModifyTodoUseCase,
    @Inject(UseCasesProxyModule.REMOVE_TODO_USECASE)
    private readonly removeTodoUseCase: RemoveTodoUseCase,

    @Inject(UseCasesProxyModule.GET_USER_USECASE)
    private readonly getUserUseCase: GetUserUseCase,
  ) {}

  @Mutation(() => TodosSchema, { name: TODO_RESOLVER.CREATE_TODO })
  async createTodo(@UserDecorator() user: User, @Args('body') body: CreateTodoDto) {
    const todo = await this.createTodoUseCase.execute({
      ...body,
      createdBy: user.id,
      updatedBy: user.id,
      assigneer: user.id,
    });

    return TodosSchema.normalize(todo);
  }

  @ResolveField(() => UsersSchema, { name: 'assigneer' })
  async getAssigneer(@Parent() parent: TodosSchema) {
    const user = await this.getUserUseCase.execute({ id: parent.assigneer });

    return UsersSchema.normalize(user);
  }

  @Query(() => [TodosSchema], { name: TODO_RESOLVER.TODOS })
  async getListTodo() {
    return this.getListTodoUseCase.execute({});
  }

  @Query(() => TodosSchema, { name: TODO_RESOLVER.TODO })
  async getOneTodo(@UuidV4Decorator() todoId: string) {
    return this.getTodoUseCase.execute({ id: todoId });
  }

  @ResolveField(() => UsersSchema, { name: 'assignee', nullable: true })
  async getAssignee(@Parent() parent: TodosSchema) {
    if (!parent.assignee) return null;

    const user = await this.getUserUseCase.execute({ id: parent.assigneer });

    return UsersSchema.normalize(user);
  }

  @Mutation(() => TodosSchema, { name: TODO_RESOLVER.MODIFY_TODO })
  async modifyTodo(@Args('body') body: ModifyTodoDto, @UserIdDecorator() userId: string) {
    const { id: todoId, ...dataUpdate } = body;
    const todo = await this.modifyTodoUseCase.execute({ todoId, dataUpdate, userId });

    return TodosSchema.normalize(todo);
  }

  @Mutation(() => Boolean, { name: TODO_RESOLVER.DELETE_TODO })
  async deleteTodo(@UuidV4Decorator() todoId: string, @UserIdDecorator() userId: string) {
    return this.removeTodoUseCase.execute({ todoId, userId });
  }
}
