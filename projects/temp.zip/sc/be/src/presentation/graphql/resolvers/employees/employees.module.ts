import { Module } from '@nestjs/common';
import { EmployeesResolver } from './employees.resolver';

@Module({
  imports: [],
  providers: [EmployeesResolver],
  exports: [],
})
export class EmployeesModule {}
