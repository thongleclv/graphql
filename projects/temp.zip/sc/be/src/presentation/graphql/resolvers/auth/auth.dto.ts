import { Field, InputType, PickType } from '@nestjs/graphql';
import { IsString, IsStrongPassword, MaxLength } from 'class-validator';
import { MAX_LENGTH_STRING } from '@application/common/constants';

@InputType()
export class SignupDto {
  @Field()
  @IsString()
  @MaxLength(MAX_LENGTH_STRING)
  username: string;

  @Field()
  @IsStrongPassword({ minLength: 6 })
  password: string;
}

@InputType()
export class LoginDto extends PickType(SignupDto, ['username']) {
  @Field()
  @IsString()
  password: string;
}
