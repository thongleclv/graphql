import { Field, InputType, PartialType } from '@nestjs/graphql';
import { IsEnum, IsString, IsUUID } from 'class-validator';
import { TodoStatus } from './todos.schema';

@InputType()
export class CreateTodoDto {
  @Field()
  @IsString()
  title: string;

  @Field()
  @IsString()
  description: string;

  @Field()
  @IsEnum(TodoStatus)
  status: string;
}

@InputType()
export class ModifyTodoDto extends PartialType(CreateTodoDto) {
  @Field()
  @IsUUID('4')
  id: string;
}
