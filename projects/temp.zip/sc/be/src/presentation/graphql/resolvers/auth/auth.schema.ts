import { Field, ObjectType } from '@nestjs/graphql';

@ObjectType('Auth')
export class AuthSchema {
  @Field()
  accessToken: string;

  @Field()
  refreshToken: string;

  static normalize(auth: AuthSchema) {
    return {
      accessToken: auth.accessToken,
      refreshToken: auth.refreshToken,
    };
  }
}
