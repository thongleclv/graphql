import { Inject } from '@nestjs/common';
import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { PublicDecorator, USER_RESOLVER, UserDecorator } from '@presentation/graphql/common';
import { UsersSchema } from './users.schema';
import { User } from '@domain/entities';
import { UseCasesProxyModule } from '@infrastructure/useCasesProxy';
import { AddUserUseCase, GetListUserUseCase } from '@application/useCases';
import { AddEmployeeDto } from './users.dto';

@Resolver(() => UsersSchema)
export class UsersResolver {
  constructor(
    @Inject(UseCasesProxyModule.GET_LIST_USER_USECASE)
    private readonly getListUserUseCase: GetListUserUseCase,
    @Inject(UseCasesProxyModule.ADD_USER_USECASE)
    private readonly addUserUseCase: AddUserUseCase,
  ) {}

  @Query(() => UsersSchema, { name: USER_RESOLVER.PROFILE })
  async getProfile(@UserDecorator() user: User) {
    return UsersSchema.normalize(user);
  }

  @PublicDecorator()
  @Mutation(() => UsersSchema, { name: USER_RESOLVER.ADD_USER })
  async addUser(@Args('body') body: AddEmployeeDto) {
    const { employeeCode } = body;
    const userReturn = await this.addUserUseCase.execute(employeeCode);

    return UsersSchema.normalize(userReturn);
  }

  @PublicDecorator()
  @Query(() => [UsersSchema])
  async users() {
    const users = await this.getListUserUseCase.execute();
    return users.map(UsersSchema.normalize);
  }
}
