import { PublicDecorator, AUTH_RESOLVER } from '@presentation/graphql/common';
import { SignupUseCase, LoginUseCase } from '@application/useCases';
import { UseCasesProxyModule } from '@infrastructure/useCasesProxy';
import { Resolver, Mutation, Args } from '@nestjs/graphql';
import { LoginDto, SignupDto } from './auth.dto';
import { AuthSchema } from './auth.schema';
import { Inject } from '@nestjs/common';

@PublicDecorator()
@Resolver(() => AuthSchema)
export class AuthResolver {
  constructor(
    @Inject(UseCasesProxyModule.LOGIN_USECASE)
    private readonly loginUseCase: LoginUseCase,
    @Inject(UseCasesProxyModule.SIGNUP_USECASE)
    private readonly signupUseCase: SignupUseCase,
  ) {}

  @Mutation(() => AuthSchema, { name: AUTH_RESOLVER.LOGIN })
  async login(@Args('body') body: LoginDto) {
    const data = await this.loginUseCase.execute({ ...body });

    return AuthSchema.normalize(data);
  }

  @Mutation(() => AuthSchema, { name: AUTH_RESOLVER.SIGN_UP })
  async signup(@Args('body') body: SignupDto) {
    const data = await this.signupUseCase.execute({ ...body });

    return AuthSchema.normalize(data);
  }
}
