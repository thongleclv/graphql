import { TodosModule, AuthModule, UsersModule } from '@presentation/graphql/resolvers';
import { Module } from '@nestjs/common';
import { JwtGuard } from './common';
import { JwtModule } from '@infrastructure/libs';
import { APP_GUARD } from '@nestjs/core';
import { DatabaseModule } from '@infrastructure/databases/database.module';
import { EmployeesModule } from './resolvers/employees/employees.module';

@Module({
  imports: [
    JwtModule,
    DatabaseModule,

    // Resolvers
    AuthModule,
    TodosModule,
    UsersModule,
    EmployeesModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtGuard,
    },
  ],
})
export class GraphQLResolversModule {}
