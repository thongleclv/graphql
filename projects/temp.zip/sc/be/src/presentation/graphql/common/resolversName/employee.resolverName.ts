export const EMPLOYEE_RESOLVER = {
  // Mutation
  IMPORT_EMPLOYEES: 'importEmployees',
};
