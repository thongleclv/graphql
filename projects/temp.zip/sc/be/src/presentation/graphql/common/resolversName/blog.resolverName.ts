export const BLOG_RESOLVER = {
  // Query
  BLOGS: 'blogs',
  BLOG: 'blog',

  // Mutation
  CREATE_BLOG: 'createBlog',

  // Subscription
  BLOG_ADDED: 'blogAdded',
};
