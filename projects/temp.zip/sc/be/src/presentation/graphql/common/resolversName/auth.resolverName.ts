export const AUTH_RESOLVER = {
  SIGN_UP: 'signup',
  LOGIN: 'login',
};
