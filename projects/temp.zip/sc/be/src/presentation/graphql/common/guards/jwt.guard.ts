import { ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { GqlExecutionContext } from '@nestjs/graphql';
import { IS_PUBLIC_KEY } from '@presentation/graphql/common';
import { Request } from 'express';
import { JwtAdapter } from '@domain/adapters';
import { DatabaseContextAbstract } from '@domain/abstracts';

@Injectable()
export class JwtGuard {
  constructor(
    private reflector: Reflector,
    private jwtService: JwtAdapter,
    private dbContext: DatabaseContextAbstract,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const ctx = GqlExecutionContext.create(context);
    const { req } = ctx.getContext<{ req: Request }>();

    // Check if the route is public
    const isPublic = this.reflector.getAllAndOverride<boolean>(
      IS_PUBLIC_KEY, //
      [ctx.getHandler(), ctx.getClass()],
    );

    // If the route is public, skip JWT validation
    if (isPublic) {
      return true;
    }

    // Otherwise, proceed with JWT validation
    const token = req?.headers?.authorization?.replace(/^Bearer\s/, '');
    if (!token) return false;

    const payload = await this.jwtService.verify(token);

    // If JWT validation fails, access is denied
    if (!payload) return false;

    req.user = await this.dbContext.user.findById(payload.id);
    if (!req.user) return false;

    return true;
  }
}
