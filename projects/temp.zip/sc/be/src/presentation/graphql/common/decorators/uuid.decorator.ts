import { Args } from '@nestjs/graphql';
import { UuidPipe } from '@presentation/graphql/common';

export function UuidV4Decorator() {
  return Args('id', { type: () => String }, UuidPipe);
}
