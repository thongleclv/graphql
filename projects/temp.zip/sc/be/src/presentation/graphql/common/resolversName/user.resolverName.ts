export const USER_RESOLVER = {
  // Query
  USERS: 'users',
  USER: 'user',
  PROFILE: 'profile',

  // Mutation
  CREATE_USER: 'createUser',
  ADD_USER: 'addUser',
};
