import { SetMetadata } from '@nestjs/common';

export const IS_PUBLIC_KEY = Symbol('isPublic');
export const PublicDecorator = () => SetMetadata(IS_PUBLIC_KEY, true);
