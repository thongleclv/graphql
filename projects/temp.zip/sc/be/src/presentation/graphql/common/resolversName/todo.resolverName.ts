export const TODO_RESOLVER = {
  // Query
  TODOS: 'todos',
  TODO: 'todo',
  LIST_TODO_CREATED_BY_USER: 'listTodoCreatedByUser',

  // Mutation
  CREATE_TODO: 'createTodo',
  MODIFY_TODO: 'modifyTodo',
  DELETE_TODO: 'deleteTodo',
  ASSIGN_TODO_TO_SELF: 'assignTodoToSelf',
} as const;
