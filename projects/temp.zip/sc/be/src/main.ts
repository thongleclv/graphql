import { NestFactory } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { logger: ['error', 'warn'] });

  const config = app.get(ConfigService);

  const port = config.get('port');
  const env = config.get('env');

  // @TODO: set origin FE
  app.enableCors();

  await app.listen(port, async () => {
    console.info(`\n\n==========================================`);
    console.info(`        ENV: ${env}    `);
    console.info(`🚀🚀 Graphql playground running on the url: http://localhost:${port}/graphql 🚀🚀`);
    console.info(`==========================================`);
  });
}

bootstrap();
