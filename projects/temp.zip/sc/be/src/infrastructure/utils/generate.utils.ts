export const generateId = (prefix: string, sequenceName: string) => {
  return `CONCAT('${prefix}', to_char(CURRENT_DATE, 'YYYYMMDD'), nextval('${sequenceName}'::regclass))`;
};
