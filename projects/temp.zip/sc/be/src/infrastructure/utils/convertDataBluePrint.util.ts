import * as fs from 'fs';
import * as XLSX from 'xlsx';
import * as csvtojson from 'csvtojson';
import { join } from 'path';
import { writeFile } from 'fs/promises';

const convertFromJson = async (path: string = 'files/employees.json') => {
  const data = await new Promise<any[]>((resolve, reject) => {
    let jsonData = '';

    const readStream = fs.createReadStream(path, 'utf8');

    readStream.on('data', chunk => {
      jsonData += chunk;
    });

    readStream.on('error', error => {
      console.error('An error occurred:', error.message);
      reject(error.message);
    });

    readStream.on('end', () => {
      resolve(JSON.parse(jsonData) as any[]);
    });
  });

  return data.map(item => ({
    employeeName: item.employeeName,
    country: item.country,
    employeeCode: item.employeeCode,
    startDate: item.startDate,
    endDate: item.endDate,
    companyRole: item.companyRole,
    companyRoleLevel: item.companyRoleLevel,
    managedBy: item.managedBy,
  }));
};

const convertFromCSV = async () => {
  const basePath = join(__dirname, '../../../files');
  const csvFilePath = join(`${basePath}/employees.csv`);
  try {
    const jsonData = await csvtojson().fromFile(csvFilePath);
    await writeFile(join(`${basePath}/employees_csv_to_json.json`), JSON.stringify(jsonData, null, 2));
  } catch (e) {
    console.log(e);
    throw new Error(e);
  }
};
const convertFromExcel = () => {
  const basePath = join(__dirname, '../../../files');
  const excelFilePath = join(`${basePath}/employees.xlsx`);
  const workbook = XLSX.readFile(excelFilePath);
  const sheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[sheetName];
  const arrData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
  const headerRow = arrData[0];
  const jsonData = arrData.slice(1).map(el => ({
    [headerRow[0]]: el[0],
    [headerRow[1]]: el[1],
    [headerRow[2]]: el[2],
    [headerRow[3]]: el[3],
    [headerRow[4]]: el[4] || null,
    [headerRow[5]]: el[5],
    [headerRow[6]]: el[6],
    [headerRow[7]]: el[7],
  }));
  writeFile(join(`${basePath}/employees_excel_to_json.json`), JSON.stringify(jsonData, null, 2));
  return jsonData;
};

export const convertDataBluePrint = {
  json: convertFromJson,
  csv: convertFromCSV,
  excel: convertFromExcel,
};

convertFromJson();
