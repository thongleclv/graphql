import { DynamicModule, Global, Module } from '@nestjs/common';
import { JwtAdapter, HashAdapter } from '@domain/adapters';
import { DatabaseContextAbstract } from '@domain/abstracts';
import { HashModule, JwtModule } from '@infrastructure/libs';
import { DatabaseModule } from '@infrastructure/databases/database.module';
import {
  LoginUseCase,
  SignupUseCase,
  CreateTodoUseCase,
  ModifyTodoUseCase,
  GetListTodoUseCase,
  GetTodoUseCase,
  RemoveTodoUseCase,
  GetUserUseCase,
  GetListUserUseCase,
  ImportEmloyeesUseCase,
  AddUserUseCase,
} from '@application/useCases';
import { ConfigService } from '@nestjs/config';

@Global()
@Module({
  imports: [DatabaseModule, HashModule, JwtModule],
})
export class UseCasesProxyModule {
  // Auth
  static SIGNUP_USECASE = Symbol('SIGNUP_USECASE');
  static LOGIN_USECASE = Symbol('LOGIN_USECASE');

  // TODO
  static CREATE_TODO_USECASE = Symbol('CREATE_TODO_USECASE');
  static MODIFY_TODO_USECASE = Symbol('MODIFY_TODO_USECASE');
  static REMOVE_TODO_USECASE = Symbol('REMOVE_TODO_USECASE');
  static GET_LIST_TODO_USECASE = Symbol('GET_LIST_TODO_USECASE');
  static GET_TODO_USECASE = Symbol('GET_TODO_USECASE');

  // USER
  static GET_USER_USECASE = Symbol('GET_USER_USECASE');
  static GET_LIST_USER_USECASE = Symbol('GET_LIST_USER_USECASE');
  static ADD_USER_USECASE = Symbol('ADD_USER_USECASE');

  // EMPLOYEE
  static IMPORT_EMPLOYEES = Symbol('IMPORT_EMPLOYEES');

  static register(): DynamicModule {
    return {
      module: UseCasesProxyModule,
      providers: [
        // AUTH
        {
          inject: [DatabaseContextAbstract, JwtAdapter, HashAdapter],
          provide: UseCasesProxyModule.SIGNUP_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract, jwtService: JwtAdapter, hashService: HashAdapter) =>
            new SignupUseCase(dbContext, jwtService, hashService),
        },
        {
          inject: [DatabaseContextAbstract, JwtAdapter, HashAdapter],
          provide: UseCasesProxyModule.LOGIN_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract, jwtService: JwtAdapter, hashService: HashAdapter) =>
            new LoginUseCase(dbContext, jwtService, hashService),
        },

        // TODO
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.CREATE_TODO_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new CreateTodoUseCase(dbContext),
        },
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.MODIFY_TODO_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new ModifyTodoUseCase(dbContext),
        },
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.GET_LIST_TODO_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new GetListTodoUseCase(dbContext),
        },
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.GET_TODO_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new GetTodoUseCase(dbContext),
        },
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.REMOVE_TODO_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new RemoveTodoUseCase(dbContext),
        },

        // USER
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.GET_USER_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new GetUserUseCase(dbContext),
        },
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.GET_LIST_USER_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract) => new GetListUserUseCase(dbContext),
        },
        {
          inject: [DatabaseContextAbstract, HashAdapter, ConfigService],
          provide: UseCasesProxyModule.ADD_USER_USECASE,
          useFactory: (dbContext: DatabaseContextAbstract, hashService: HashAdapter, config: ConfigService) =>
            new AddUserUseCase(dbContext, hashService, config),
        },

        // EMPLOYEE
        {
          inject: [DatabaseContextAbstract],
          provide: UseCasesProxyModule.IMPORT_EMPLOYEES,
          useFactory: (dbContext: DatabaseContextAbstract) => new ImportEmloyeesUseCase(dbContext),
        },
      ],
      exports: [
        // AUTH
        UseCasesProxyModule.SIGNUP_USECASE,
        UseCasesProxyModule.LOGIN_USECASE,

        // TODO
        UseCasesProxyModule.CREATE_TODO_USECASE,
        UseCasesProxyModule.MODIFY_TODO_USECASE,
        UseCasesProxyModule.REMOVE_TODO_USECASE,
        UseCasesProxyModule.GET_LIST_TODO_USECASE,
        UseCasesProxyModule.GET_TODO_USECASE,

        // USER
        UseCasesProxyModule.GET_USER_USECASE,
        UseCasesProxyModule.GET_LIST_USER_USECASE,
        UseCasesProxyModule.ADD_USER_USECASE,
        // EMPLOYEE
        UseCasesProxyModule.IMPORT_EMPLOYEES,
      ],
    };
  }
}
