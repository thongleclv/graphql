import { Injectable } from '@nestjs/common';
import { JwtService as NestJwtService } from '@nestjs/jwt';
import { JwtAdapter } from '@domain/adapters';
import { ConfigService } from '@nestjs/config';
import { JwtPayloadInterface } from '@domain/interfaces';

@Injectable()
export class JwtService implements JwtAdapter {
  constructor(
    private nestJwtService: NestJwtService,
    private configService: ConfigService,
  ) {}

  sign(payload: JwtPayloadInterface) {
    return this.nestJwtService.signAsync(payload, {
      secret: this.configService.get('jwt.atKey'),
      expiresIn: this.configService.get('jwt.expireIn'),
    });
  }

  verify(token: string) {
    try {
      return this.nestJwtService.verifyAsync<JwtPayloadInterface>(token, {
        secret: this.configService.get('jwt.atKey'),
      });
    } catch (error) {
      console.error('🚀 ~ JwtService ~ verify ~ error:', error);
      return null;
    }
  }
}
