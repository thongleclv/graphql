import { Module } from '@nestjs/common';
import { HashAdapter } from '@domain/adapters';
import { HashService } from './hash.service';

@Module({
  providers: [{ provide: HashAdapter, useClass: HashService }],
  exports: [HashAdapter],
})
export class HashModule {}
