import * as bcrypt from 'bcrypt';
import { Injectable } from '@nestjs/common';
import { HashAdapter } from '@domain/adapters';

@Injectable()
export class HashService implements HashAdapter {
  async hash(data: string, saltOrRounds = 10): Promise<string> {
    try {
      return await bcrypt.hash(data, saltOrRounds);
    } catch (error) {
      console.error(`HashService::hash ${error.message}`);
      return '';
    }
  }

  async compare(data: string | Buffer, encrypted: string): Promise<boolean> {
    try {
      return await bcrypt.compare(data, encrypted);
    } catch (error) {
      console.error(`HashService::compare:: ${error.message}`);
      return false;
    }
  }
}
