import { LoggerModule as SquareboatLoggerModule } from '@squareboat/nestjs-logger';
import { LoggerError } from '@application/common/constants';
import { Environment } from '@application/common/enums';
import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { LoggersService } from './loggers.service';
import * as winston from 'winston';
import * as path from 'path';

@Global()
@Module({
  imports: [
    SquareboatLoggerModule.registerAsync({
      isGlobal: false,
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const { combine, timestamp, printf } = winston.format;
        const format = combine(
          timestamp(),
          printf(({ message, timestamp }) => {
            return `${timestamp} ${message}`;
          }),
        );

        const config = {
          [Environment.Production]: new winston.transports.File({
            filename: path.join(process.cwd(), 'logs', `${LoggerError.ServerInternalError}.log`),
            format,
          }),
        };

        return {
          isGlobal: false,
          default: `${LoggerError.ServerInternalError}`,
          disableConsole: false,
          loggers: {
            [LoggerError.ServerInternalError]: {
              level: 'error',
              transports: [config[configService.get('env', '')] || new winston.transports.Console({ format })],
            },
          },
        };
      },
    }),
  ],
  providers: [LoggersService],
  exports: [LoggersService],
})
export class LoggersModule {}
