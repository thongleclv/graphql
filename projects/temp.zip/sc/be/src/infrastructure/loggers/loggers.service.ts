import { Injectable } from '@nestjs/common';
import { Logger } from '@squareboat/nestjs-logger';
import { LoggerError } from '@application/common/constants';

@Injectable()
export class LoggersService {
  constructor() {}

  error(name: LoggerError, ...args: any[]) {
    Logger(`${LoggerError.ServerInternalError}`).error(`--- ${name} --- ${JSON.stringify(args, null, 2)}\n`);
  }
}
