export const ID_PROPERTIES = {
  user: {
    prefix: 'usr',
    sequenceName: 'cps_project_cps_usr_seq',
  },
  employee: {
    prefix: 'emp',
    sequenceName: 'cps_project_cps_empe_seq',
  },
};
