import { Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: async (config: ConfigService) => ({
        type: 'postgres',
        host: config.get('DB_HOST'),
        port: Number(config.get('DB_PORT')),
        username: config.get('DB_USERNAME'),
        password: config.get('DB_PASSWORD'),
        entities: ['dist/src/infrastructure/databases/postgres/entities/*.entity.{js,ts}'],
        database: config.get('DB_NAME'),
        synchronize: false,
        retryAttempts: Infinity,
      }),
    }),
  ],
})
export class PostgresConfigModule {}
