import { Module } from '@nestjs/common';
import { Environment } from '@application/common/enums';
import { plainToInstance } from 'class-transformer';
import { ConfigModule as ConfigModuleNestJs } from '@nestjs/config';
import { IsBoolean, IsEnum, IsNumber, IsOptional, IsString, validateSync } from 'class-validator';

class EnvironmentVariables {
  // App
  @IsEnum(Environment)
  NODE_ENV: Environment;
  @IsNumber()
  PORT: number;
  @IsString()
  DEFAULT_PW: string;

  // DB
  @IsString()
  DB_HOST: string;
  @IsNumber()
  DB_PORT: number;
  @IsString()
  DB_USERNAME: string;
  @IsString()
  DB_PASSWORD: string;
  @IsString()
  DB_NAME: string;

  // JWT
  @IsString()
  EXPIRE_IN: string;
  @IsString()
  ACCESS_TOKEN_KEY: string;

  // DEBUG
  @IsOptional()
  @IsBoolean()
  DEBUG: boolean;
}

const validateEnv = (config: Record<string, unknown>) => {
  const validatedConfig = plainToInstance(EnvironmentVariables, config, {
    enableImplicitConversion: true,
  });

  const errors = validateSync(validatedConfig, {
    skipMissingProperties: false,
  });

  if (errors?.length > 0) {
    console.info('\n😻 ---------------Validating .env.* file--------------- 😻');
    console.error(errors.map(e => e.constraints));
    process.exit(1);
  }

  return validatedConfig;
};

const configEnv = () => ({
  port: parseInt(process.env.PORT),

  env: process.env.NODE_ENV,
  isProd: Environment.Production === process.env.NODE_ENV,
  isDev: Environment.Development === process.env.NODE_ENV,
  defaultPassword: process.env.DEFAULT_PW,
  jwt: {
    atKey: process.env.ACCESS_TOKEN_KEY,
    expireIn: process.env.EXPIRE_IN,
  },

  database: {
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT),
    username: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    name: process.env.DB_NAME,
  },

  debug: Boolean(process.env.DEBUG === 'true'),
});

@Module({
  imports: [
    ConfigModuleNestJs.forRoot({
      isGlobal: true,
      expandVariables: true,
      envFilePath: ['.env', '.env.development'],
      validate: validateEnv,
      cache: true,
      load: [configEnv],
    }),
  ],
})
export class ConfigModule {}
