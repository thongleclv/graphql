import { MigrationInterface, QueryRunner } from 'typeorm';
import { formatYYYYMMDD } from '@infrastructure/utils';
import { HashService } from '@infrastructure/libs';

export class $npmConfigName1706151081551 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const userId = `usr${formatYYYYMMDD()}1`;
    const password = await new HashService().hash('Cps@2024');

    await queryRunner.query(
      `INSERT INTO public."CPS_USER" ("USR_ID", "USR_NM", "USR_PWD") VALUES ('${userId}', 'superadmin', '${password}')`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM public."CPS_USER" WHERE USR_NM = 'superadmin'`);
  }
}
