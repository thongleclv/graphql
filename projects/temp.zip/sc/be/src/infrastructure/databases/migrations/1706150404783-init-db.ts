import { MigrationInterface, QueryRunner } from 'typeorm';

export class $npmConfigName1706150404783 implements MigrationInterface {
  name = ' $npmConfigName1706150404783';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE SEQUENCE public.cps_project_cps_urs_seq
            INCREMENT 1
            START 1
            MINVALUE 1
            MAXVALUE 9999999999
            CACHE 1;`,
    );
    await queryRunner.query(
      `CREATE SEQUENCE public.cps_project_cps_empe_seq
            INCREMENT 1
            START 1
            MINVALUE 1
            MAXVALUE 9999999999
            CACHE 1;`,
    );
    await queryRunner.query(
      `CREATE TABLE "CPS_USER" ("CRE_DT" TIMESTAMP NOT NULL DEFAULT now(), "UPD_DT" TIMESTAMP NOT NULL DEFAULT now(), "DELT_FLG" "public"."CPS_USER_delt_flg_enum" NOT NULL DEFAULT 'N', "USR_ID" character varying NOT NULL, "USR_NM" character varying NOT NULL, "USR_PWD" character varying NOT NULL, "LST_LGIN" integer, "USR_STS" character varying NOT NULL DEFAULT true, CONSTRAINT "UQ_a242a8d771e7d45b1314fb2490f" UNIQUE ("USR_NM"), CONSTRAINT "PK_b4c9f7ea7ac2fea8d02cc07bfbf" PRIMARY KEY ("USR_ID"))`,
    );
    await queryRunner.query(
      `CREATE TABLE "CPS_EMPE" ("CRE_DT" TIMESTAMP NOT NULL DEFAULT now(), "UPD_DT" TIMESTAMP NOT NULL DEFAULT now(), "DELT_FLG" "public"."CPS_EMPE_delt_flg_enum" NOT NULL DEFAULT 'N', "EMPE_ID " SERIAL NOT NULL, "EMPE_NM" character varying NOT NULL, "CNT" character varying NOT NULL, "EMPE_CD" integer NOT NULL, "ST_DT" TIMESTAMP NOT NULL, "END_DT" TIMESTAMP NOT NULL, "EMPE_STS" character varying NOT NULL, "USR_ID" character varying NOT NULL, CONSTRAINT "UQ_cf0649c56dd74481c00e28b556b" UNIQUE ("EMPE_NM"), CONSTRAINT "UQ_7b5ea8e282157f19f5ba13d4ba6" UNIQUE ("EMPE_CD"), CONSTRAINT "REL_50266e3f5807c61e6742c93fd2" UNIQUE ("USR_ID"), CONSTRAINT "PK_e8c561e61fe7d92179c6cd815d5" PRIMARY KEY ("EMPE_ID "))`,
    );
    await queryRunner.query(
      `CREATE TABLE "Todo" ("CRE_DT" TIMESTAMP NOT NULL DEFAULT now(), "UPD_DT" TIMESTAMP NOT NULL DEFAULT now(), "DELT_FLG" "public"."Todo_delt_flg_enum" NOT NULL DEFAULT 'N', "id" character varying NOT NULL, "title" character varying NOT NULL, "description" character varying NOT NULL, "status" character varying NOT NULL, "assignee" character varying, "assigneer" character varying NOT NULL, "createdBy" character varying NOT NULL, "updatedBy" character varying NOT NULL, CONSTRAINT "PK_7c134d062947a53f89064491e63" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `ALTER TABLE "CPS_EMPE" ADD CONSTRAINT "FK_50266e3f5807c61e6742c93fd2e" FOREIGN KEY ("USR_ID") REFERENCES "CPS_USER"("USR_ID") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "Todo" ADD CONSTRAINT "FK_24d89bea19edec338b7541f0209" FOREIGN KEY ("createdBy") REFERENCES "CPS_USER"("USR_ID") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "Todo" ADD CONSTRAINT "FK_b8ac74705cbe32fcd4dc0098f3a" FOREIGN KEY ("updatedBy") REFERENCES "CPS_USER"("USR_ID") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "Todo" DROP CONSTRAINT "FK_b8ac74705cbe32fcd4dc0098f3a"`);
    await queryRunner.query(`ALTER TABLE "Todo" DROP CONSTRAINT "FK_24d89bea19edec338b7541f0209"`);
    await queryRunner.query(`ALTER TABLE "CPS_EMPE" DROP CONSTRAINT "FK_50266e3f5807c61e6742c93fd2e"`);
    await queryRunner.query(`DROP TABLE "Todo"`);
    await queryRunner.query(`DROP TABLE "CPS_EMPE"`);
    await queryRunner.query(`DROP TABLE "CPS_USER"`);
  }
}
