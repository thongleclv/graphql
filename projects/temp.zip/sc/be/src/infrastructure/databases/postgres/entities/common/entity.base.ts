import { Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { BaseEntityInterface } from '@domain/entities';

export enum DeletedValue {
  YES = 'Y',
  NO = 'N',
}
export abstract class BaseEntity implements Omit<BaseEntityInterface, 'id'> {
  @CreateDateColumn({ name: 'CRE_DT' })
  createdAt: Date;

  @Column({ name: 'CRE_USR_ID', default: 'usr202401011' })
  createdBy: string;

  @UpdateDateColumn({ name: 'UPD_DT' })
  updatedAt: Date;

  @Column({ name: 'UPD_USR_ID', default: 'usr202401011' })
  updatedBy: string;

  @Column({ type: 'enum', enum: DeletedValue, default: DeletedValue.NO, name: 'DELT_FLG' })
  deleted?: DeletedValue;
}
