import { User, Todo, Employee } from '@domain/entities';
import { Injectable, OnApplicationBootstrap } from '@nestjs/common';
import { DatabaseContextAbstract } from '@domain/abstracts';
import { DataSource, EntityManager, QueryRunner, Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { TodoEntity, UserEntity, EmployeeEntity } from './entities';
import { UserRepository, TodoRepository } from './repositories';
import {} from './entities/employee.entity';
import { EmployeeRepository } from './repositories/employee.repository';

@Injectable()
export class PostgresService implements DatabaseContextAbstract, OnApplicationBootstrap {
  readonly queryRunner: QueryRunner;
  readonly manager: EntityManager;

  user: UserRepository;
  todo: TodoRepository;
  employee: EmployeeRepository;

  constructor(
    @InjectRepository(UserEntity)
    private userRepository: Repository<User>,
    @InjectRepository(EmployeeEntity)
    private employeeRepository: Repository<Employee>,
    @InjectRepository(TodoEntity)
    private todoRepository: Repository<Todo>,
    private dataSource: DataSource,
  ) {
    this.queryRunner = this.dataSource.createQueryRunner();
    this.manager = this.queryRunner.manager;
  }

  onApplicationBootstrap() {
    this.user = new UserRepository(this.userRepository);
    this.employee = new EmployeeRepository(this.employeeRepository);
    this.todo = new TodoRepository(this.todoRepository);
  }

  async startTransaction(): Promise<void> {
    await this.queryRunner.connect();
    return await this.queryRunner.startTransaction();
  }

  async commitTransaction(): Promise<void> {
    return await this.queryRunner.commitTransaction();
  }

  async rollbackTransaction(): Promise<void> {
    return await this.queryRunner.rollbackTransaction();
  }

  async releaseTransaction(): Promise<void> {
    return await this.queryRunner.release();
  }

  async transaction<T>(callback: (manager: EntityManager) => Promise<T>): Promise<T> {
    return await this.dataSource.manager.transaction(callback);
  }
}
