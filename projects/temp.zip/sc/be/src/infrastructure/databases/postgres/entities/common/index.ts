export * from './entity.base';
