import { PostgresGenericRepository } from '../postgres.genericRepository';
import { TodoRepositoryInterface } from '@domain/repositories';
import { Todo } from '@domain/entities';

export class TodoRepository extends PostgresGenericRepository<Todo> implements TodoRepositoryInterface {}
