import { faker } from '@faker-js/faker';
import { sample, sampleSize } from 'lodash';
import { writeFile } from 'fs/promises';
import * as fs from 'fs';
import { join } from 'path';
import { convertDataBluePrint } from '../../../../utils';
export const genEmployees = async () => {
  const COMPANY_ROLE = [
    'developer', //
    'tester',
    'group_manager',
    'ppo',
    'po',
    'accountant',
    'hr',
    'scrum_master',
  ];
  const COMPANY_ROLE_LEVEL = ['intern', 'fresher', 'middle', 'senior'];
  const COUNTRY = ['vietnam', 'korean', 'india'];
  const RANDOM_NUMBER = 800;
  const FOLDER = join(__dirname, '../data');
  const NUMBER_OF_GROUP_MANAGER = 5;
  const EMPLOYEE_CODES = new Set<number>();
  const DATA = [];

  function randomEmployees() {
    let employeeCode: number;
    do {
      employeeCode = faker.number.int({ min: 100000, max: 300000 });
    } while (EMPLOYEE_CODES.has(employeeCode));

    EMPLOYEE_CODES.add(employeeCode);

    return {
      employeeName: faker.person.fullName({}),
      country: sample(COUNTRY),
      employeeCode,
      startDate: faker.date.past(),
      endDate: Math.random() < 0.1 ? faker.date.past() : null,
      companyRole: sample(COMPANY_ROLE),
      companyRoleLevel: sample(COMPANY_ROLE_LEVEL),
      managedBy: null,
    };
  }

  Array.from({ length: RANDOM_NUMBER }).forEach(() => {
    DATA.push(randomEmployees());
  });

  const managerIds = sampleSize([...EMPLOYEE_CODES], NUMBER_OF_GROUP_MANAGER);
  DATA.forEach(employee => {
    // If employee.employeeCode is not in array of managerId => employee must manager by someone
    if (!managerIds.some(managerId => managerId === employee.employeeCode)) {
      employee.managedBy = sample(managerIds);
    }
  });

  if (!fs.existsSync(FOLDER)) {
    fs.mkdirSync(FOLDER, { recursive: true });
  }

  await writeFile(join(`${FOLDER}/employees.json`), JSON.stringify(DATA, null, 2));
};

export const genEmployeesFromExcelFile = async () => {
  const jsonData = convertDataBluePrint.excel();
  return jsonData;
};

export const genEmployeesFromCSV = async () => {
  const jsonData = convertDataBluePrint.csv();
  return jsonData;
};
