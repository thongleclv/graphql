import { User } from '@domain/entities';
import { BaseEntity } from './common';
import { Column, Entity, PrimaryColumn } from 'typeorm';
import { generateId } from '@infrastructure/utils';
import { ID_PROPERTIES } from '@infrastructure/common/constants';

enum UserStatus {
  Active = 'Active',
  Inactive = 'Inactive',
}
@Entity('CPS_USR')
export class UserEntity extends BaseEntity implements User {
  @PrimaryColumn({
    name: 'USR_ID',
    default: () => generateId(ID_PROPERTIES.user.prefix, ID_PROPERTIES.user.sequenceName),
  })
  id: string;

  @Column({ name: 'USR_NM', unique: true })
  username: string;

  @Column({ name: 'USR_PWD' })
  password: string;

  @Column({ nullable: true, name: 'LST_LGIN' })
  lastLoggedIn?: number;

  @Column({ type: 'enum', enum: UserStatus, default: UserStatus.Active, name: 'USR_STS' })
  status: UserStatus;
}
