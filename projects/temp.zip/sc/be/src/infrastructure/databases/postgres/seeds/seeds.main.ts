import { NestFactory } from '@nestjs/core';
import { AppModule } from '@src/app.module';
import { DatabaseContextAbstract } from '@domain/abstracts';
import { HashAdapter } from '@domain/adapters';

async function seedData() {
  const app = await NestFactory.createApplicationContext(AppModule);

  const db = app.get(DatabaseContextAbstract);
  const hashService = app.get(HashAdapter);

  await db.user.insertOne({
    username: 'super_admin',
    password: await hashService.hash('Cps@2024'),
  });

  await app.close();
}

seedData();
