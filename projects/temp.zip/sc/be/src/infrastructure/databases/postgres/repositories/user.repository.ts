import { PostgresGenericRepository } from '../postgres.genericRepository';
import { UserRepositoryInterface } from '@domain/repositories';
import { User } from '@domain/entities';

export class UserRepository extends PostgresGenericRepository<User> implements UserRepositoryInterface {}
