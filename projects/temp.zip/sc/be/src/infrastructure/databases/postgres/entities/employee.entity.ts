import { Employee } from '@domain/entities';
import { BaseEntity } from './common';
import { Column, Entity, JoinColumn, OneToOne, PrimaryColumn } from 'typeorm';
import { UserEntity } from './user.entity';
import { ID_PROPERTIES } from '@infrastructure/common/constants';
import { generateId } from '@infrastructure/utils';

@Entity('CPS_EMPE')
export class EmployeeEntity extends BaseEntity implements Employee {
  @PrimaryColumn({
    name: 'EMPE_ID',
    default: () => generateId(ID_PROPERTIES.employee.prefix, ID_PROPERTIES.employee.sequenceName),
  })
  id: string;

  @Column({ name: 'EMPE_NM' })
  employeeName: string;

  @Column({ name: 'ACC_ID', unique: true })
  accountId: string;

  @Column({ name: 'CNT' })
  country: string;

  @Column({ name: 'EMPE_CD', unique: true })
  employeeCode: string;

  @Column({ name: 'ST_DT' })
  startDate: Date;

  @Column({ name: 'END_DT', nullable: true })
  endDate: Date;

  @Column({ name: 'EMPE_STS' })
  status: string;

  @Column({ name: 'USR_ID', nullable: true })
  userId: string;
  @OneToOne(() => UserEntity, (user: UserEntity) => user.id)
  @JoinColumn({ name: 'USR_ID' })
  user: UserEntity;
}
