import { genEmployeesFromExcelFile } from './generateEmployee';

(async () => {
  await Promise.all([
    // genEmployees(),
    genEmployeesFromExcelFile(),
    // genEmployeesFromCSV(),
  ]);
})();
