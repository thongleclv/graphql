import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';
import { EmployeeEntity, TodoEntity, UserEntity } from './entities';
import { PostgresService } from './postgres.service';
import { DatabaseContextAbstract } from '@domain/abstracts';
import { PostgresConfigModule } from '@infrastructure/configs';

@Module({
  imports: [PostgresConfigModule, TypeOrmModule.forFeature([UserEntity, TodoEntity, EmployeeEntity])],
  providers: [{ provide: DatabaseContextAbstract, useClass: PostgresService }],
  exports: [DatabaseContextAbstract],
})
export class PostgresModule {}
