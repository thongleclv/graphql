import { BaseEntity } from './common';
import { Column, Entity, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { Todo } from '@domain/entities/todo.entity';
import { UserEntity } from '.';

@Entity('Todo')
export class TodoEntity extends BaseEntity implements Todo {
  @PrimaryColumn({ generated: 'uuid' })
  id: string;

  @Column()
  title: string;

  @Column()
  description: string;

  @Column()
  status: string;

  @Column({ nullable: true })
  assignee: string;

  @Column()
  assigneer: string;

  @Column()
  createdBy: string;
  @ManyToOne(() => UserEntity, (user: UserEntity) => user.id)
  @JoinColumn({ name: 'createdBy' })
  creator: UserEntity;

  @Column()
  updatedBy: string;
  @ManyToOne(() => UserEntity, (user: UserEntity) => user.id)
  @JoinColumn({ name: 'updatedBy' })
  updater: string;
}
