import { EmployeeRepositoryInterface } from '@src/domain/repositories';
import { PostgresGenericRepository } from '../postgres.genericRepository';
import { Employee } from '@domain/entities';

export class EmployeeRepository extends PostgresGenericRepository<Employee> implements EmployeeRepositoryInterface {}
