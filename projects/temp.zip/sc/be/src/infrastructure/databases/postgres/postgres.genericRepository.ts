import { Injectable } from '@nestjs/common';
import { GenericRepositoryAbstract } from '@domain/abstracts';
import { Repository } from 'typeorm';
import { DeletedValue } from './entities/common';

@Injectable()
export class PostgresGenericRepository<T> implements GenericRepositoryAbstract<T> {
  private repository: Repository<T>;

  constructor(repository: Repository<T>) {
    this.repository = repository;
  }

  async softDelete(id: string, user_id: string): Promise<boolean> {
    const result = await this.repository.update(id, {
      updatedBy: user_id,
      deleted: DeletedValue.YES,
    } as any);
    return !!result.affected;
  }

  findById(id: string): Promise<T> {
    return this.findOne({ id });
  }

  isExists(condition: any): Promise<boolean> {
    return this.repository.exists({ where: condition });
  }

  findAll(): Promise<T[]> {
    return this.repository.find();
  }

  async insertOne(item: Partial<T>): Promise<T> {
    const entity = this.repository.create(item as T);
    return entity;
    // return this.repository.save(entity);
  }

  async save(data: T): Promise<T> {
    return this.repository.save(data);
  }

  async findByIdAndUpdate(id: string, item: Partial<T>) {
    await this.repository.update(id, item as any);
    return this.repository.findOne({ where: { id } as any });
  }

  async findOne(condition: any): Promise<T> {
    return await this.repository.findOne({ where: condition });
  }

  async insertMany(data: Partial<T>[]): Promise<T[]> {
    const entity = this.repository.create(data as T[]);
    return this.repository.save(entity);
  }
}
