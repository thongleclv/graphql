import { GenericRepositoryAbstract } from '@domain/abstracts';
import { Employee } from '@domain/entities';

export abstract class EmployeeRepositoryInterface extends GenericRepositoryAbstract<Employee> {}
