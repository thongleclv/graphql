import { GenericRepositoryAbstract } from '@domain/abstracts';
import { User } from '@domain/entities';

export abstract class UserRepositoryInterface extends GenericRepositoryAbstract<User> {}
