import { GenericRepositoryAbstract } from '@domain/abstracts';
import { Todo } from '@domain/entities';

export abstract class TodoRepositoryInterface extends GenericRepositoryAbstract<Todo> {}
