import { BaseEntityInterface } from '@domain/entities';
import { BaseUserAuditInterface } from './common';

export interface Todo extends BaseEntityInterface, BaseUserAuditInterface {
  title: string;
  description: string;
  status: string;
  assignee: string;
  assigneer: string;
}
