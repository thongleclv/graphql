import { BaseEntityInterface } from '@domain/entities';

export interface User extends BaseEntityInterface {
  /** Username */
  username: string;
  /** Password */
  password: string;
  /** Last time the user logged in */
  lastLoggedIn?: number;
  /** Status */
  status: string;
}
