import { BaseEntityInterface } from './common';

export interface Employee extends BaseEntityInterface {
  /** Employee's name */
  employeeName: string;
  /** Email */
  // email: string;
  /** Blueprint ID */
  accountId: string;
  /** Employee's nationality  */
  country: string;
  /** Employee's code  */
  employeeCode: string;
  /** Date of joining the company */
  startDate: Date;
  /** Date of leaving the company */
  endDate?: Date;
  // /** Employee role ID */
  // companyRoleId: number;
  // /** Employee role level ID */
  // companyRoleLevelId: number;
  // /** Group manager  */
  // groupManagerId: number;
  /** Employee status (active or inactive) */
  status: string;
  /** Foreign key from user table*/
  userId: string;
}
