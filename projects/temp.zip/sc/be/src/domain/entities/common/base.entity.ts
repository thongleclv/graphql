export interface BaseEntityInterface {
  id: string;
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date;
}

export interface BaseUserAuditInterface {
  createdBy: string;
  updatedBy: string;
}
