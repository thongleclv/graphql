export interface JwtPayloadInterface {
  id: string;
}
