import { User } from '@domain/entities';

declare module 'express' {
  interface Request {
    user: User;
  }
}
