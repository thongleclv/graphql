import { JwtPayloadInterface } from '@domain/interfaces';

export abstract class JwtAdapter {
  abstract sign(payload: JwtPayloadInterface): Promise<string>;
  abstract verify(token: string): Promise<JwtPayloadInterface | null>;
}
