export abstract class HashAdapter {
  abstract hash(data: string, saltOrRounds?: number): Promise<string>;
  abstract compare(data: string | Buffer, encrypted: string): Promise<boolean>;
}
