export abstract class GenericRepositoryAbstract<T> {
  abstract findAll(): Promise<T[]>;

  abstract findOne(condition: any): Promise<T>;

  abstract findById(id: string): Promise<T>;

  abstract insertOne(item: Partial<T>): Promise<T>;

  abstract insertMany(item: Partial<T>[]): Promise<T[]>;

  abstract save(item: Partial<T>): Promise<T>;

  abstract findByIdAndUpdate(id: string, item: Partial<T>): Promise<T>;

  abstract isExists(condition: any): Promise<boolean>;

  abstract softDelete(id: string, user_id: string): Promise<boolean>;
}
