export abstract class ErrorResponseAbstract {
  errorCode: string;
  data?: any;
  message?: string;
  devMessage?: any;
}
