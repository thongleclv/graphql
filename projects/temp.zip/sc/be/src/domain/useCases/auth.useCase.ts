export interface LoginUseCaseResponseInterface {
  accessToken: string;
  refreshToken: string;
}

export interface SignupUseCaseResponseInterface {
  accessToken: string;
  refreshToken: string;
}
