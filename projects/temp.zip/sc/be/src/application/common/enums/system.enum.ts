export enum Environment {
  Development = 'development',
  Production = 'production',
  Staging = 'staging',
  Uat = 'uat',
}
