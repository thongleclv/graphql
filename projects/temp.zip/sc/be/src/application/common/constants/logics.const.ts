export const MAX_LENGTH_PASSWORD = 50;
export const MAX_LENGTH_STRING = 100;
