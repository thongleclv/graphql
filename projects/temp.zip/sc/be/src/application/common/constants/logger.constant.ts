export enum LoggerError {
  ServerInternalError = 'SERVER_INTERNAL_ERROR',
}
