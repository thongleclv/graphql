import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { User } from '@domain/entities';
import { ErrorResponse } from '@application/utils';
import { EMPLOYEE_EXCEPTION, USER_EXCEPTION } from '@application/exceptions';
import { HashAdapter } from '@domain/adapters';
import { ConfigService } from '@nestjs/config';

export class AddUserUseCase implements UseCaseAbstract<string, User> {
  constructor(
    private dbContext: DatabaseContextAbstract,
    private hashService: HashAdapter,
    private config: ConfigService,
  ) {}

  async execute(employeeCode: string) {
    try {
      const employeeInfo = await this.dbContext.employee.findOne({ employeeCode });
      if (!employeeInfo) {
        throw ErrorResponse({ errorCode: EMPLOYEE_EXCEPTION.NOT_FOUND });
      }

      const existsUser = await this.dbContext.user.findOne({ username: employeeInfo.employeeCode });

      if (existsUser) {
        throw ErrorResponse({ errorCode: USER_EXCEPTION.USER_CODE_EXISTED });
      }

      this.dbContext.startTransaction();
      try {
        const defaultPassword = this.config.get('defaultPassword');
        const hashedPassword = await this.hashService.hash(defaultPassword);

        const user = await this.dbContext.user.insertOne({
          password: hashedPassword,
          username: employeeInfo.employeeCode,
        });
        await this.dbContext.user.save(user);

        employeeInfo.userId = user.id;
        await this.dbContext.employee.save(employeeInfo);
        this.dbContext.commitTransaction();

        return user;
      } catch (error) {
        this.dbContext.rollbackTransaction();
        throw error;
      }
    } catch (error) {
      throw error;
    }
  }
}
