import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { User } from '@domain/entities';
import { TODO_EXCEPTION } from '@application/exceptions';
import { ErrorResponse } from '@application/utils';

export class GetUserUseCase implements UseCaseAbstract<{ id: string }, User> {
  constructor(private repository: DatabaseContextAbstract) {}

  async execute({ id }: { id: string }) {
    const user = await this.repository.user.findById(id);

    if (!user) {
      throw ErrorResponse({ errorCode: TODO_EXCEPTION.ASSIGNEER_NOT_FOUND });
    }

    return user;
  }
}
