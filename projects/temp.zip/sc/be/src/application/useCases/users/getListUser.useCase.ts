import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { User } from '@domain/entities';

export class GetListUserUseCase implements UseCaseAbstract<object, User[]> {
  constructor(private repository: DatabaseContextAbstract) {}

  async execute() {
    const users = await this.repository.user.findAll();

    return users;
  }
}
