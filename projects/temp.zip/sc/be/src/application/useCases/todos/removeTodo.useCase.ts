import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';

export class RemoveTodoUseCase implements UseCaseAbstract<{ todoId: string; userId: string }, boolean> {
  constructor(private repository: DatabaseContextAbstract) {}

  async execute(param: { todoId: string; userId: string }) {
    return this.repository.todo.softDelete(param.todoId, param.userId);
  }
}
