import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { Todo } from '@domain/entities';

export class CreateTodoUseCase implements UseCaseAbstract<Partial<Todo>, Todo> {
  constructor(private repository: DatabaseContextAbstract) {}

  execute(item: Partial<Todo>) {
    return this.repository.todo.insertOne(item);
  }
}
