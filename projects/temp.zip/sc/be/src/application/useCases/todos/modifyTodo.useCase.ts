import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { Todo } from '@domain/entities';
import { ErrorResponse } from '@application/utils';
import { TODO_EXCEPTION } from '@application/exceptions';

export class ModifyTodoUseCase
  implements UseCaseAbstract<{ todoId: string; dataUpdate: Omit<Partial<Todo>, 'id'>; userId: string }, Todo>
{
  constructor(private repository: DatabaseContextAbstract) {}

  async execute(param: { todoId: string; dataUpdate: Omit<Partial<Todo>, 'id'>; userId: string }) {
    const todo = await this.repository.todo.findById(param.todoId);
    if (!todo) throw ErrorResponse({ errorCode: TODO_EXCEPTION.NOT_FOUND });

    return await this.repository.todo.findByIdAndUpdate(param.todoId, {
      ...param.dataUpdate,
      updatedBy: param.userId,
    });
  }
}
