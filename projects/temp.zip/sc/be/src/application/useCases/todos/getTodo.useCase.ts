import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { Todo } from '@domain/entities';
import { ErrorResponse } from '@application/utils';
import { TODO_EXCEPTION } from '@application/exceptions';

export class GetTodoUseCase implements UseCaseAbstract<{ id: string }, Todo> {
  constructor(private repository: DatabaseContextAbstract) {}

  async execute({ id }: { id: string }) {
    const todo = await this.repository.todo.findById(id);

    if (!todo) {
      throw ErrorResponse({ errorCode: TODO_EXCEPTION.NOT_FOUND });
    }

    return todo;
  }
}
