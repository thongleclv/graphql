import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { Todo } from '@domain/entities';

export class GetListTodoUseCase implements UseCaseAbstract<any, Todo[]> {
  constructor(private repository: DatabaseContextAbstract) {}

  async execute(_: any) {
    return await this.repository.todo.findAll();
  }
}
