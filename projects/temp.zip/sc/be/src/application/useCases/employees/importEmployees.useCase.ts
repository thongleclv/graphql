import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { Employee } from '@domain/entities';

export class ImportEmloyeesUseCase implements UseCaseAbstract<Partial<Employee>[], Employee[]> {
  constructor(private repository: DatabaseContextAbstract) {}
  async execute(data: Partial<Employee>[]) {
    return this.repository.employee.insertMany(data);
  }
}
