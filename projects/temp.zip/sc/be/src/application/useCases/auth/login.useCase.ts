import { HashAdapter, JwtAdapter } from '@domain/adapters';
import { AUTH_EXCEPTION } from '@application/exceptions';
import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { ErrorResponse } from '@application/utils';
import { User } from '@domain/entities';
import { LoginUseCaseResponseInterface } from '@domain/useCases';

export class LoginUseCase
  implements UseCaseAbstract<Pick<User, 'username' | 'password'>, LoginUseCaseResponseInterface>
{
  constructor(
    private dbContext: DatabaseContextAbstract,
    private jwtService: JwtAdapter,
    private hashService: HashAdapter,
  ) {}

  async execute(userInput: Pick<User, 'username' | 'password'>) {
    const user = await this.dbContext.user.findOne({ username: userInput.username });

    if (!user) {
      throw ErrorResponse({ errorCode: AUTH_EXCEPTION.INVALID_CREDENTIAL });
    }

    if (!(await this.hashService.compare(userInput.password, user.password))) {
      throw ErrorResponse({ errorCode: AUTH_EXCEPTION.INVALID_CREDENTIAL });
    }

    const token = await this.jwtService.sign({
      id: user.id,
    });

    return {
      accessToken: token,
      refreshToken: '',
    };
  }
}
