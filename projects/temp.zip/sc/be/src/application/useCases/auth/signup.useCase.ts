import { JwtAdapter, HashAdapter } from '@domain/adapters';
import { USER_EXCEPTION } from '@application/exceptions';
import { DatabaseContextAbstract, UseCaseAbstract } from '@domain/abstracts';
import { User } from '@domain/entities';
import { ErrorResponse } from '@application/utils';
import { Injectable } from '@nestjs/common';
import { SignupUseCaseResponseInterface } from '@domain/useCases';

@Injectable()
export class SignupUseCase
  implements UseCaseAbstract<Pick<User, 'username' | 'password'>, SignupUseCaseResponseInterface>
{
  constructor(
    private dbContext: DatabaseContextAbstract,
    private jwtService: JwtAdapter,
    private hashService: HashAdapter,
  ) {}

  async execute(user: Pick<User, 'username' | 'password'>) {
    const isUsernameExisted = await this.dbContext.user.isExists({ username: user.username });
    if (isUsernameExisted) {
      throw ErrorResponse({ errorCode: USER_EXCEPTION.USERNAME_EXISTED });
    }

    await this.dbContext.startTransaction();

    // Using QueryRunner to create and control state of single database connection
    try {
      user.password = await this.hashService.hash(user.password);

      const newUser = await this.dbContext.user.insertOne(user);

      await this.dbContext.manager.save(newUser);

      const token = await this.jwtService.sign({
        id: newUser.id,
      });

      await this.dbContext.commitTransaction();

      return {
        accessToken: token,
        refreshToken: '',
      };
    } catch (err: any) {
      await this.dbContext.rollbackTransaction();
      throw err;
    } finally {
      await this.dbContext.releaseTransaction();
    }

    // Creating and using transactions
    // return await this.dbContext.transaction<SignupUseCaseResponseInterface>(async manager => {
    //     user.password = await this.hashService.hash(user.password);

    //     const newUser = await this.dbContext.user.insertOne(user);

    //     const token = await this.jwtService.sign({
    //         id: newUser.id,
    //     });

    //     // The most important restriction when working in a transaction is to ALWAYS use the provided instance of
    //     // entity manager - transactionalEntityManager in this example.
    //     // DO NOT USE GLOBAL ENTITY MANAGER.
    //     // All operations MUST be executed using the provided transactional entity manager.
    //     await manager.save(newUser);

    //     return {
    //         accessToken: token,
    //         refreshToken: '',
    //     };
    // });
  }
}
