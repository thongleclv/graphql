import { GlobalException, formatError } from '@presentation/graphql/common';
import { DatabaseModule } from '@infrastructure/databases/database.module';
import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { LoggersModule } from '@infrastructure/loggers/loggers.module';
import { ConfigModule, GraphQLConfigsModule, ValidateConfig } from '@infrastructure/configs';
import { GraphQLResolversModule } from '@presentation/graphql/graphqlResolvers.module';
import { UseCasesProxyModule } from '@infrastructure/useCasesProxy';

@Module({
  imports: [
    ConfigModule,
    DatabaseModule,

    GraphQLConfigsModule.register({
      formatError,
      context: () => {
        return {
          dataLoaders: {},
        };
      },
    }),
    GraphQLResolversModule,

    LoggersModule,

    UseCasesProxyModule.register(),

    ValidateConfig,
  ],
  providers: [
    // Interceptors

    // Exceptions
    {
      provide: APP_FILTER,
      useClass: GlobalException,
    },
  ],
})
export class AppModule {}
